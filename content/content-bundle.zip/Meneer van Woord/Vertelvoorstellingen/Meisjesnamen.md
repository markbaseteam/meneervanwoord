---
dg-publish: true
---
Doris: Griekse naam, betekent Geschenk van God en Geschenk van de oceaan
Inaya: Arabische naam, betekent Geschenk van God en Zorgzaam
Zosja: zorgzaam
Djenna: Paradijs, zorgzaam
