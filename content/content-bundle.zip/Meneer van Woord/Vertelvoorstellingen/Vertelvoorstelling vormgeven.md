---
dg-publish: true
---
up:: [[Literature MOC]]
tags:: #vertelvoorstelling #brainstorm

# Vertelvoorstelling vormgeven

Vertelthema: Schatgraven naar woorden
Er zijn zoveel verborgen verhalen, pak je lamp en schop en zoek.

- Goede verhalen
- Slechte verhalen
  Kunnen goede verhalen slecht gebruikt worden?
  Kunnen slechte verhalen goed gebruikt worden?

![[Drawing 2023-03-20 13.22.23.excalidraw]]

## De Woordenwegenwacht (of de Woordenweger)

Wat is de Woordenwegenwacht of de Woordenweger voor persoon?

Wat doet hij of zij, waarom bestaat er zoiets? 
Ik zit vast in het woord 'meer'. Wat betekent dat woord? Ik weet het niet meer.
Wil ik nu meer, of wil ik minder meer?
Of wil ik zwemmen in een meer?
Is een verhaal min of meer goed of is een verhaal min of meer slecht?

Fausto wil altijd meer, hij heeft alles al wat hij kan bezitten, maar hij krijgt meer en meer het gevoel dat er nog iets mist. Hij heeft het gevoel dat hij minder heeft dan hij zou kunnen hebben. Tijdens een wandeling langs zijn bezittingen, bedenkt hij dat er iets is dat hij nog niet heeft: de natuur! Hij onderwerpt de natuur, totdat hij bij de zee komt. De zee laat hem zien hoe dwaas het is om de natuur te willen bezitten en Fausto verdrinkt.

Een meisje (Maria) ziet dat er steeds minder bomen komen, de mensen in het dorp hebben last van de hitte die erger wordt omdat er geen bomen zijn. Het meisje besluit dat er meer bomen moeten komen, iedere dorpsbewoner moet een eigen boom hebben. Ze verzamelt dfe pitten die de mensen uitspugen en zaait die in potten. Zo zorgt ze ervoor dat iedere bewoner in de schaduw van de boom kan zitten.

Fausto en Maria willen allebei meer, meer en meer. Welk meer weegt zwaarder?
[[Meisjesnamen]]
