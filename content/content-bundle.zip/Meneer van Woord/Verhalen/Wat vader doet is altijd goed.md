````
Genre: Volksverhaal
Herkomst: Scandinavië
````
```
```
EXPOSITIE

Er waren eens een boer en een boerin.

Ze woonden in een klein boerderijtje. Ze hielden ontzettend van elkaar. De boerin zei altijd tegen haar man: "Vader, wat jij doet is altijd goed"

Ze waren niet rijk en ze waren niet arm.

MOTORISCH MOMENT

Toch moesten ze op een dag hun laatste dier, een paard verkopen.

"Of ruilen, dat kan ook" , zei de boerin. "Jij komt altijd met iets moois terug"

Ze gaf hem een dikke kus en de boer ging op weg naar de jaarmarkt in het dorp verderop.

CONFLICTONTWIKKELING

-   Hij komt een andere boer tegen. Met een koe. Een koe geeft melk, dat is nog eens mooi, Van melk kun je kaas maken, slagroom, yoghurt. Hij ruilt het paard tegen de koe, Nu kan ik eigenlijk wel naar huis, want ik heb een goede ruil gedaan. Maar naar de jaarmarkt is eigenlijk ook leuk. Dus gaat hij verder op weg naar het dorp
-   Hij komt een man tegen met een schaap. Een schaap, die geeft wol, daar kun je een trui van breien, een sjaal of een lange onderbroek. Een schaap hoeft niet in de stal, die kan bij ons in huis slapen. En hij ruilt de koe voor het schaap
-   Hij komt een man tegen met een vette gans onder de arm. Oh, daar zou moeder de vrouw blij mee zijn. Een vette gans, die kunnen we lekker vetmesten en opeten als het kerst is. Wat zou dat een lekker kerstmaal zijn. En hij ruilt het schaap voor de gans
-   Bij een viersprong zit een man met een prachtige haan. Een mooie rode kam op zijn kop, groene veren, blauwe veren, gouden veren. En wat kan hij prachtig kraaien. Stel je voor dat je elke morgen wakker wordt met dat prachtige gekraai. En hij ruilt de gans voor de haan
-   Dan komt hij een man tegen met een volle zak op zijn rug. Hij vraagt wat er in zit. Deze zak zit helemaal vol met appels, vers geplukt uit onze boomgaard. Ik krijg er vast veel geld voor op de markt, maar de zak is wel heel zwaar. Appels, dacht de boer, daar kun je appeltaart van maken. Hoeveel taarten zou je daar niet mee kunnen maken? Het water loopt in zijn mond. Wil je jouw zak met appels ruilen voor mijn haan? Ben je meteen van je zware last af. En hij ruilt de haan voor de zak met appels

CLIMAX

Hij komt in het dorp , gaat naar de herberg en zet zijn zak met appels bij de brandende kachel. Hij gaat zitten bestelt een beker bier en een bord bonen. Hij raakt aan de praat met drie rijke mannen die er ook zitten te eten. "Weet je nog een goed verhaal? "vragen de mannen aan de boer. En hij vertelt over zijn paard dat hij heeft geruild voor uiteindelijk een zak appels.

-   Dan horen ze de kleine plofjes. De appels zijn zo warm geworden dat ze zijn gepoft.

"Ik denk niet dat je vrouw heel blij zal zijn als je thuiskomt" zegt een van de rijke mannen.

"Jawel hoor, ze zal me veel kusjes geven"

"Wedden van niet?" zeggen de rijke mannen. "Als je vrouw je veel kusjes geeft, krijg je van ons een zak met goud. Als ze je geen kusjes geeft, krijgen wij de zak met gepofte appels"

De rijke mannen namen de boer mee in hun gouden koets en zo reden ze terug naar het huis van de boer.

AFWIKKELING

De boer komt thuis. Zijn vrouw zegt: "Daar ben je eindelijk. Vader, ik ben benieuwd wat je voor ons paard hebt gekregen"

-   Ik heb ons paard geruild voor een koe

-   Een koe, wat een goed idee, dan hebben we altijd melk, voor kaas en slagroom

-   JA, maar de koe heb ik weer geruild voor een schaap

-   Een schaap, wat gezellig, daar kunnen we lekker warm tegen aan slapen

-   Ja, maar het schaap heb ik weer geruild voor een gans

-   Een gans, wat goed, dan kunnen we iedere dag een ei eten en ik houd zo van gebraden gans

-   Ja, maar de gans heb ik weer geruild voor een haan

-   Een haan, wat goed van jou, nu zullen we nooit meer te laat opstaan

-   Ja, maar de haan heb ik weer geruild voor een zak met appels

-   Appels! Wat ben je toch een schat. Je weet hoe gek ik ben op appels en appeltaart.

-   Ja, maar de appels zijn gepoft, omdat ik ze te dicht bij de kachel had gezet

-   Dat is toevallig: de boerin van de boerderij hiernaast vroeg vandaag of ik nog varkensvoer had, want bij haar was alles op. Ik had niks, maar nu kan ik haar een hele zak geven. Wat een goede grap! E ze overlaadde de boer met kusjes

De rijke mannen die door de ramen keken, konden hun ogen niet geloven. Mensen die elkaar zo vertrouwen: dat moeten worden beloond. En ze haalden een grote zak met goud uit hun gouden koets.

"waar is dat nou voor nodig? "vroeg de boerin "Wat vader doet is altijd goed!"

Maar ze pakte toch snel de zak met goud.

En ze leefden nog lang en goudgelukkig
