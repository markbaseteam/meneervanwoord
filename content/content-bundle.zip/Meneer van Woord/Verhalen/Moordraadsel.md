---
Genre: Griezelverhaal
Leeftijd: Basisschool
---

# Moordraadsel

Baron van Heeckeren Molecaten woont in een groot landhuis aan de rand van het bos. Hij is rijk, heel rijk. Samen met zijn vrouw Hélène woont hij er op zijn gemak.

Op een zondagochtend wordt hij vermoord met een scherp voorwerp dat in zijn hart gestoken is.

De politie ondervraagt alle aanwezigen in het huis

Hélène: Ik was het niet, ik sta zondags pas rond het middaguur op

De kokkin: Ik was het niet, Ik sneed groenten en fruit voor het diner van vanavond. Meneer en mevrouw geven vanavond een diner voor vrienden

De butler: Ik was het niet, ik was het zilver aan het poetsen, Alles moest blinken voor het diner van vanavond. Anders zwaait er wat

De meid: Ik was het niet, ik haalde de post uit de brievenbus. Ik was lang onderweg, de oprijlaan is anderhalve kilometer lang

De tuinman: Ik was het niet, ik sneed bloemen in de tuin en maakt er boeketten van in de schuur. Allemaal voor het diner van vanavond.

De politie had al snel door wie het had gedaan
