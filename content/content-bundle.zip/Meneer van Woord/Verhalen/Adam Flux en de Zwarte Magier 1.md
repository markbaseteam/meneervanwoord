---
Genre: Griezelverhaal
Auteur: Paul van Loon
Leeftijd: Basisschool
dg-publish: true
---

# Adam Flux en de Zwarte Magiër

De toren

Het was al laat in de avond, toen Adam Flux het De Nijmeegse bossen uitliep en zijn tocht voortzette door de Hatertse Vennen. Drie weken was hij nu al onderweg, sinds
hij zijn woonplaats verlaten had. Die woonplaats was Slaapgat, en het was beslist de saaiste plaats op de hele aardbol. Misschien zelfs in het heelal, dacht Adam weleens, al viel dat moeilijk te bewijzen. Slaapgat had het platste en saaiste landschap, er stonden de saaiste huizen, er woonden de saaiste mensen en er gebeurde nooit iets.

Drie weken geleden was Adam veertien geworden. Op die dag was hij weggegaan om wat van de wereld te zien, avonturen te beleven, te reizen. Eigenlijk vooral om te ontsnappen aan dat saaie dorp voordat hij zelf ook voor de rest van zijn leven een van die Slaapgatters zou zijn. Sinds hij het dorp verlaten had, was zijn leven een stuk opwindender geworden. Voor een jongen van veertien viel er van alles te beleven in de wereld. Leuke dingen en ook gevaarlijke dingen. Alles was beter dan wonen in  Slaapgat.

Opgelucht en tevreden wandelde Adam het Weerwoud uit. Hij was opgelucht, omdat hij heelhuids en zonder kleerscheuren uit het Weerwoud te voorschijn was gekomen.
Daar wemelde het van de weerwolven. Ook kropen er nog allerlei andere
weerwezens rond, die zó eng waren dat ze niet eens een naam hadden. Tevreden
was Adam, omdat hij onderweg in het Weerwoud toch nog een konijntje had weten
te verschalken. Dat had hij boven een klein vuurtje geroosterd en samen met wat
veldwortels smakelijk opgepeuzeld.

Terwijl Adam Flux glimlachend wandelde, groepten inktzwarte wolken samen rond de maan. De wind loeide door de heuvels en plotseling kletterden regendruppels hard op
hem neer. Adam trok zijn groene jas over zijn hoofd maar dat hielp weinig. In een mum van tijd was hij doorweekt en nergens was een schuilplaats. Vanuit het Weerwoud achter hem klonk een langgerekt gehuil. Het was volle maan en de weerwolven en andere weerwezens kropen uit hun schuilplaats. Adam zag hen in gedachten al voor zich, met hun bloedrode ogen en ontblote tanden.

Adam rilde. Wat, als ze hem hier in de Holle Heuvels achterna kwamen? Weerwolven
waren dol op dit beestenweer.

Hij begon te hollen. Wolken wervelden langs de maan. Er klonk een keiharde knetterende knal. Een gevorkte bliksemschicht sprong van heuveltop tot heuveltop. In die felle lichtflits zag Adam een reusachtige donkere vorm voor zich opdoemen. Een
gebouw, een toren was het. Het leek wel of de bliksem hem daar met één klap had
neergezet. Wat het ook was, hij kon er schuilen. Met weerwolven en een boze
onweersbui op je hielen moest je niet te kieskeurig zijn, vond Adam. Hij holde
recht naar de toren toe. Vreemd genoeg stond de deur op een kier, alsof iemand
hem verwachtte. Adam stapte vlug naar binnen. De deur sloeg met een klap achter
hem dicht.

Adam stond in een ronde kamer. De verlichting kwam van kaarsen die aan de muur hingen. Vlak onder het plafond zweefden kristallen bollen die het kaarslicht
reflecteerden. Ze hingen daar als kleine en grotere planeten in het heelal en
draaiden traag om en langs elkaar heen.

In het midden van de kamer was op de vloer een grote cirkel geschilderd. Hij was
verdeeld in verschillende vakken met symbolen en tekens waar Adam geen snars
van begreep. Behalve de deur waardoor Adam binnen was gekomen, was er nog een
andere deur. De kamer was verder leeg. Adam staarde naar de zwevende kristallen
bollen en vroeg zich af hoe ze konden zweven zonder te vallen.

Een stem als een donderslag verbrak de stilte. Adam maakte een sprong van schrik.
"Interessant schouwspel niet?" zei de stem. "Je kijkt naar de beroemde zwevende kristallenverzameling van Iblis de Oude."

Adam draaide zich om. Precies in het midden van de geschilderde cirkel stond een
lange, magere gestalte. Waar hij vandaan kwam was een raadsel. Hij was gehuld
in een wijde zwarte mantel en droeg een spitse zwarte hoed van wel een meter
hoog. De hoed had een brede rand, die een schaduw over het gezicht legde. Adam
zag alleen een lange spitse neus en de rode gloed van de ogen.

Rode ogen!
Adam huiverde.

De lange man begon opeens op een aangename manier te praten.

"Welkom in mijn toren, Adam Flux, brave jongen. Ik zie nu al aan je ogen dat je uit
dankbaarheid voor de schuilplaats graag bereid bent iets voor mij te doen, niet
waar?"

Bij die laatste woorden gloeiden de rode ogen even op.

"Na-natuurlijk, meneer," stamelde Adam. "Ik doe graag iets voor een ander hoor."
Hij werd een beetje duizelig van die starende rode ogen. Hoe wist die rare snuiter trouwens zijn naam?

"Mooi zo. Ik heb een aardige opdracht voor je. Als je die goed uitvoert, krijg je een
fraaie beloning. Kijk maar." De man strekte zijn arm uit en een van de kristallen bollen zweefde zachtjes van het plafond naar beneden. De man plukte hem uit de lucht en liet hem draaien in zijn hand. "Een waardevol kristal uit de collectie van Iblis de Oude zal jouw eigendom worden, Adam!"

Adam hield zijn adem in. Nog nooit had hij zo iets moois gezien. De kristallen bol bood
een toverachtige aanblik, blauwe vonken spetterden in het rond.

De magiër grijnsde en verborg met een snel gebaar de bol onder zijn mantel.

"Goed dan. Laten we eerst de opdracht bespreken. De tijd dringt. Ik wil dat je voor
mij een fjonk vangt, in de fjonkmoerassen.

"In orde," zei Adam dromerig. "Komt voor de bakker."

Hij had nog nooit van een fjonk of van de fjonkmoerassen gehoord, maar zijn gedachten konden de kristallen bol niet loslaten.

"Stil en luister!" zei de magiër. "Fjonken zijn kleine wezentjes, harig, rond als een bol en ze hebben twee kikkerachtige poten. Ze beschikken over bepaalde magische krachten die zeer bruikbaar zijn voor mij. Een leek als jij, niet ingewijd in de magie, heeft er niks aan." De rode ogen keken Adam strak aan.

"Slechts eenmaal in de honderd jaar komen de fjonken uit de moerassen tevoorschijn.
Vannacht is het zover! En jij krijgt de eer Adam, om een fjonk voor mij te vangen. Fantastisch toch?"

Adam probeerde een beetje helder te denken.

"Wacht eens even! Hoe moet ik zo" neh... fjonk vangen? En is het niet gevaarlijk
in dat moeras?"

"Maar maar, beste jongen," zei de magiër. "Met een vlindernetje en wat
handigheid heb je in een wip een fjonk gevangen. 

Als ik niet door een vloek aan deze toren gekluisterd was, zou ik het heus zelf wel
doen. Maar helaas hebben een aantal vijandige tovenaars een web van spreuken
rond mijn toren geweven, toverspreuken die te sterk zijn voor mij. Ik zit gevangen. Maar jij Adam Flux, jij kunt gaan en staan waar je wilt. Niets weerhoudt je."

"Ja ja," mompelde Adam, "ja ja, maar is het geváárlijk in dat moeras?"

"Ben je mal, beste jongen," zei de magiër breed lachend. "Er bestaat een heel kleine kans dat je de Molkroch tegen het lijf loopt, maar die slaapt meestal en hij is erg schuw heb ik gehoord. Bovendien eet hij alleen maar bomen."

"Doei," zei Adam. "Bij nader inzien moet ik dringend ergens anders heen." Hij liep vlug naar de deur.

"Wacht!" donderde Iblis de Oude.

Adam wilde wel verder lopen, maar dat ging niet.

"Jij schijnt het niet te begrijpen, mannetje," fluisterde de magiër. "Jij zult deze nacht een fjonk voor mij vangen! Ik heb niemand anders. Bovendien heb je weinig keus. Er zijn hier maar twee deuren, weet je. Achter de deur waar jij door gekomen bent, staan de weerwolven van het Weerwoud je op te wachten. Hoor maar!"

Hij wees naar de deur die onmiddellijk op een kiertje openging. Een bloeddorstig gehuil
drong naar binnen. Behaarde poten met lange klauwen kwamen om de hoek en graaiden en klauwden woest in de lucht. Adam deinsde terug. Met een klap sloeg
de deur weer dicht.

"Zie je wat ik bedoel?" grijnsde Iblis de Oude. Hij wees naar de andere deur. "Loop door die deur en je staat meteen in de fjonkmoerassen. Meteen. Alles wat je hoeft te doen, is vlug een,fjonk vangen. Dan kom je terug en krijg je je beloning. Simpel."

Om Adam te overtuigen haalde hij nog even de schitterende bol onder zijn mantel uit.
"Nou, wat zal het zijn?" Binnen in de bol flonkerden. een miljoen sterren. Een handvol heelal. "Nou, vooruit dan," mompelde Adam. "Zó moeilijk kan het niet zijn.
Vroeger was ik heel goed in kikkers vangen." - "Mooi zo!" Vlug stopte de magiër Adam een vlindernet je in zijn handen en duwde hem naar de deur. "Tot straks, Adam." - "Tot straks," zei Adam zachtjes en liep door de magische deur. Achter zijn rug veranderde de magiër kakelend in een zwarte vleermuis. Maar dat zag Adam niet meer.

In de Fjonkmoerassen

Adam keek verbaasd om zich heen. Hij stond midden op een drassig pad. Overal zwermden muggen. Dunne mist dreef in slierten rond grillige boomstronken. De maan was een bleke schijf en hing laag tussen een paar bomen, die zich met wortels als knokige tenen aan de aarde vastgrepen. De toren van Iblis de Oude was verdwenen. Alleen de magische deur was er nog. Hij stond ingeklemd tussen twee knobbelwilgen, die er treurig uitzagen. De deur was overwoekerd met mos en moerasgras. In het midden was het teken van Iblis de Oude gebrand: de cirkel vol magische tekens, die Adam ook op de vloer van de toren gezien had.

"Deze plaats moet ik onthouden," mompelde Adam. "Want dit is waarschijnlijk de enige weg terug naar de toren van Iblis."

Hij prentte zich de plek goed in het hoofd. Toen draaide hij zich om en begon het pad te volgen. De grond was zacht en drassig en soms zakten zijn voeten tot aan de enkels weg. De mistslierten grepen naar zijn benen en dreven dan weer weg. Kikkers kwaakten en Adam dacht af en toe een zacht giebelend stemmetje te horen. Soms was er een laag ronkend geluid. Dit was nog eens wat anders dan Slaapgat.

Adam huiverde in zijn jas. Zijn kleren waren nog steeds doorweekt van de stortbui. Voor hem schoof een bruine pad door de modder. Plots doemde er uit de mist een
schommelende donkere massa op. Adam schrok zich een hoedje en dacht even dat er
een olifant op hem afkwam, maar het was een piepende, krakende wagen. Een houten kar, getrokken door een oud, versleten paard.

Voor op de wagen zat een nietig mannetje met een grote aardappelneus. Hij droeg een jas die wel vijf maten te groot was. Boven zijn enorme uitstaande oren stond een
paddestoelachtige muts.

Het mannetje liet het paard pal voor Adam stoppen. Met piepkleine oogjes keek hij
hem langdurig aan. Zijn gezicht bestond alleen maar uit rimpels en plooien.

"Goedenacht," zei hij ten slotte traag en zweeg een poos om diep en raspend adem te halen. Het paard stond stil als een huis.

"u... zoekt... iets. Anders... zou u..." Opnieuw pauzeerde hij om lucht te happen.

Zeker last van moeraslongen, dacht Adam.

"...zou u... niet hier... in de fjonkmoerassen... zijn..."

Het mannetje zakte uitgeput achterover. Hij hijgde als een jonge zeehond.

Adam legde hem vriendelijk uit waarvoor hij gekomen was, waarbij hij als bewijs met het vlindernet je zwaaide, dat de magiër hem had meegegeven. "Met dit netje wil ik een fjonk vangen," zei Adam.

Het mannetje liet deze woorden tot zich doordringen. Het duurde zo lang voor hij antwoordde, dat Adam even vreesde dat hij sliep, of dood was.

"Zooo..." zei hij na een tijdje moeizaam. Hij draaide zich zuchtend om en wees.

"Volg... het spoor... van mijn... kar. Dan kom je... vanzelf ffff... bij de fjonken. Pffff!"

Hij slaakte een diepe zucht als een ballon die leegliep. Toen keek hij Adam weer lang aan met één oog dichtgeknepen.

"Wie...stuurt jou... eigenlijk?" vroeg hij achterdochtig.

"Een zonderling met rode ogen."

"Iblis de Oude!" Het gerimpelde ventje viel van schrik haast van de wagen. Zelfs het versleten paard leek geschrokken, want het bewoog heel even een oor. Het mannetje kreeg plotseling enorme haast. Van zijn vermoeidheid was niets meer over.

"Nou tot ziens dan maar," riep hij. De kar zette zich in beweging.

"Maar... wie bent u eigenlijk?" riep Adam nog. Het mannetje draaide zich half om.
"Ik ben... maar een eenvoudige... tandarts. Met zaken... van... Iblis de Oude... wil ik niks te maken hebben." De wagen rolde wiebelend langs Adam heen. Pas toen zag Adam wat er achter op de laadbak lag. Het was een enorme kies, ongeveer zo groot als een koelkast.

Adam Flux volgde nu al een poosje het spoor van de kar, dat steeds verder het mistige
moeras in liep. De grond werd nog drassiger, de bomen grilliger en de mist dichter. Brulkikkers kwaakten luid en er waren allerlei andere geluiden, die Adam niet kende.

Vooral het zware geronk dat af en toe uit de mist kwam aanwaaien.

Adam lette niet zo op deze dingen. Hij liep nog na te grinniken over zijn ontmoeting met die wonderlijke gerimpelde tandarts. Ik hoef nergens bang voor te zijn, dacht
hij. Ik krijg een mooie kristallen bol straks.

Met klapperende vleugels verhief een moerasvogel zich uit zijn schuilplaats.
"Moab moab!" riep hij klaaglijk.

Adam schrok van de vogel, zijn kreet leek op een mensenstem. De vogel wiekte door de mist weg. Als een witte spookgedaante zag Adam hem wegvliegen en zelfs toen hij
al niet meer te zien was, hoorde Adam nog de eenzame kreet: "Moab moab."

Rechts van het pad, in het mistige moeras, klonk nu een geluid alsof er iets reusachtigs
door het water waadde. Maar het geluid verwijderde zich en Adam haalde opgelucht adem.

"Ik moet haast maken," mompelde hij. "Want het is niet helemaal pluis in dit moeras, geloof ik. Hoe eerder ik hier uit ben, hoe beter." Hij zette er flink de pas in en gleed uit over een slak zo groot als een rat. Met een smak viel hij in de blubber. De slak schuifelde verder, alsof er niets gebeurd was. Adam krabbelde kreunend overeind en veegde de modder zo goed mogelijk uit zijn gezicht en zijn haren. In de verte klonk weer de klaaglijke kreet van de witte spookvogel. Maar deze keer leek het of hij riep: "Keer om, keer om!"

Adam stak zijn tong uit naar de vogel. "Poe, ik ga niet terug voor ik een fjonk heb," riep hij. "Ik laat me heus niet bang maken door dit moeras. Als je dat maar weet." Misschien verstond de vogel hem, want hij liet zich niet meer horen.

Adam raapte zijn vlindernet je op en ging verder. De maan scheen nu helder en op sommige plaatsen was de mist wat opgelost. Hij kon de karrensporen in het pad goed volgen. Terwijl hij doorliep, voelde Adam een verandering in de sfeer om hem heen. Nog steeds stonden overal knoestige bomen, met klauwachtige wortels, maar over het gebied voor hem leek een zilveren waas te liggen. Het was een toverachtige aanblik. In het zilveren licht dansten tere doorzichtige wezentjes.

"Hier moeten die fjonken beslist ergens zitten," mompelde Adam. "Als dat niet zo is, eet ik mijn vlindernet je op." Hij bleef staan naast een zwaar overhangende boom, die hem aan een kromme heks deed denken en tuurde over het moeras.

Overal verspreid staken er een soort mosachtige heuveltjes bovenuit.

Niets bewoog. Maar plots schoot een van die heuveltjes hoog de lucht in. Het had twee 
kikkerachtige poten!

Met een reuzensprong belandde het twee meter verderop in het moeras. Daar bleef het doodstil zitten. Na een poosje kwam er ook beweging in de andere heuveltjes.
Als duveltjes uit een doosje schoten ze op kikkerpoten omhoog en stuiterden met
reuzensprongen in het rond. Met open mond keek Adam uit over het moeras, dat nu
vol was met vrolijke springers. Hij had ze gevonden: de fjonken. 

Alles wat hij nu nog moest doen, was zijn net pakken en er een vangen.

Moeraskimo

Adam sloop gebukt over de drassige moerasgrond. Hij had zijn vlindernet in de aanslag. De fjonken die even tevoren nog als vlooien rondsprongen, zaten nu weer doodstil in het moeras, als heuveltjes van mos.

Misschien slapen ze, dacht Adam hoopvol. Dan is het een koud kunstje om er een te vangen.

Met ingehouden adem bleef hij staan. Daar, op nauwelijks een meter afstand, zat een
fjonk, onbeweeglijk, zijn oogjes gesloten. Voorzichtig haalde Adam het vlindernet omhoog.

Toen liet hij het razendsnel neerkomen op de plek waar de fjonk zat, maar juist vóór het netje van Adam neerkwam, tjoepte de fjonk met een enorme sprong weg. Tjomp-tjomp, stuiterde hij door het moeras. Hij maakte daarbij een hoog, giebelend geluid.

Adam keek verbaasd naar zijn lege netje. Alle fjonken in het moeras hadden inmiddels hun ogen geopend en loerden naar hem. Kleine bolle ogen, die wit schitterden in het
maanlicht, blinkend van pret.

Ze lachen me uit! dacht Adam. Ze lachen me gewoon uit!

Het was een hoog geluid dat langzaam aanzwol. Gierend en giebelend lachten de fjonken Adam uit, vanaf hun plaatsje in het moeras. Adam werd boos. Zwaaiend met zijn vlindernet deed hij woeste uithalen naar de fjonken. Die waren hem telkens te
vlug af en kregen steeds meer pret. Met reuzensprongen suisden ze over en langs
hem heen, gillend van plezier. Ze slaakten triomfantelijke kreetjes als Adam weer missloeg.

Adam glibberde weg en viel opnieuw met zijn neus in de modder. Hij hijgde, hoestte,
proestte. Uiteindelijk ging hij verslagen zitten. Een fjonk suisde gierend langs zijn hoofd en spuwde een straal modder in zijn oog. Adam gaf het op. Die fjonken waren zo vlug als water en ongrijpbaar.

Moedeloos tuurde hij over het moeras. In het zilveren waas dat erover hing, dansten nog  steeds de doorzichtige wezentjes. Toen zag hij het handje! Een klein handje dat
net boven het zwarte water uitstak.

Adam strekte zijn arm zo ver mogelijk over het zwarte water. Hij greep het handje
beet, en met een ruk trok hij iemand uit het moeras op het droge. Het was een klein kereltje, niet groter dan een flink konijn, dat met twee handen de moeras drab uit zijn ogen wreef. Hij was groen en helemaal bloot. "Dag meneer," zei het ventje met een kwaakstem. "Is er nieuws? Is er nieuws? Is er nieuws onder de zon?"

Adam was even van zijn stuk gebracht door die vraag.

"Wat bedoel je?"

"Je hebt me toch uit de zomp boven op de kant getrokken, niet? Niet dan?" kwaakte het mannetje.

Adam knikte, maar zei niks.

"Nou dan! Daarom vraag ik: is er nieuws onder de zon? Is er? Is er?"

"Ik heb geen flauw idee," zei Adam. "Al sla je me dood. Ik dacht dat je in het moeras wegzonk. Daarom heb ik je eruit getrokken. Dat is alles. Maar ik weet niks van nieuws."

"Oooh!" kwaakte het ventje. "Ik snap. Ik snap! Je deed een goede dáád! Tenminste, je dácht dat je een goede daad deed.

Dat is aardig, maar ik hoef niet gered te worden. Ik ben Moeraskimo. Ik blijf in de moerassen tot er nieuws onder de zon is. Eerder kom ik er niet uit!" 

Hij keek Adam een ogenblik streng aan. Toen werd zijn blik weer vriendelijk. "Omdat
je bedoeling goed was, verdien je toch een prijs. Wat is je prijs? Zeg het maar! Zeg maar!"

Adam keek treurig voor zich uit. "Ik wil alleen maar een fjonk, dan kan ik weg uit
deze moerassen. Maar ze zijn te vlug voor me. Moeraskimo kneep een oog dicht en keek Adam peinzend aan. "Je prijs is niet gering," zei hij aarzelend. "Een fjonk is een bijzonder wezen. Zeer gevaarlijk als hij in verkeerde handen terechtkomt..."

Hij dacht diep na. "Maar jij hebt een goed karakter, geloof ik. Afgesproken. Ik vang
een fjonk voor jou. Ik vang! Ik vang! Een momentje graag."

Hij liet zich achterover rollen en plonsde in het zwarte water. Het duurde precies drie
seconden, voor hij weer kletsnat op de kant klauterde. Hij hield een weerloze fjonk bij de poten vast.

"Alsjeblieft! Je prijs. Je prijs."

Dolblij pakte Adam de fjonk aan. Het wezentje had zijn ogen gesloten en spartelde
helemaal niet tegen. Adam stopte het veilig weg in zijn binnenzak, waar het rustig bleef zitten.

"Dag, dag," zei Moeraskimo en wilde zich weer in het moeras laten rollen.

"Wacht!" riep Adam. "Wat voor een geheimzinnige kracht heeft deze fjonk eigenlijk?
Kun je me dat vertellen?"

 ""Als je dat wilt weten, moet je hem op je hersenpan zetten, natuurlijk,"
kwaakte Moeraskimo ongeduldig. "Nou verdwijn ik. Ik wil niet meer gestoord worden voor er nieuws onder de zon is, begrijp je?" Hij rolde van het pad af en verdween met een plons in het moeras.

"Op mijn hersenpan zetten?" Adam begreep er niks van. Is dit een hoofddeksel? dacht hij. Een pet met pootjes? Nou ja, dat moet die Iblis de Oude zelf maar uitzoeken. Als ik mijn beloning maar krijg.

Hij keek nog eenmaal naar de fjonken in het moeras, die geen aandacht meer aan hem
schonken. Ze hadden allemaal hun ogen gesloten en zonken langzaam weg in de modder. Stuk voor stuk verdwenen ze borrelend onder de oppervlakte. Met hen verdween het zilveren waas, dat over het moeras had gehangen.

Pas over honderd jaar zouden de fjonken weer te voorschijn komen, herinnerde Adam zich opeens. "Ik heb mijn fjonk," mompelde hij. "Straks krijg ik die mooie bol van kristal als beloning."

Adams enige zorg was nu om zo snel mogelijk terug te gaan naar de magische deur. Dat bleek moeilijker dan hij gedacht had. Er kropen opnieuw slierten mist over het pad. Het karrenspoor was niet meer terug te vinden. In deze schimmige wereld leken alle bomen op elkaar, zodat Adam al snel verdwaald was.

Na een poosje durfde hij geen stap meer te verzetten, bang dat hij steeds verder van
de magische deur af raakte.

Wat nu? dacht Adam. Er is hier geen mens. Niemand om me de weg te wijzen.

Moedeloos ging hij op een dikke boomwortel zitten. De kreet van de spookachtige
moerasvogel klonk eenzaam in de verte. Adam zuchtte en haalde de fjonk te voorschijn uit zijn jaszak. Het wezentje zat suf op zijn hand. Het probeerde niet te vluchten.

"Kun jij me niet helpen met je magische krachten," mompelde Adam.

Het wezentje keek hem met één oog slaperig aan.

Toen dacht Adam aan de woorden van Moeraskimo: "Je moet hem op je hersenpan zetten."

Ach, waarom ook niet? dacht Adam. Proberen kan geen kwaad. Hij pakte de fjonk beet
en zette hem op zijn hoofd. Meteen schoot er een pijnscheut door hem heen als een elektrisch stroompje, maar verder gebeurde er niets. Was Moeraskimo maar hier om mij alles uit te leggen, dacht Adam.

Nauwelijks had hij dat gedacht, of naast hem op het pad zat Moeraskimo, druipend van het water.

"Wel alle natnazzels!" riep het ventje boos. "Wat zijn dit voor nepgeintjes? Zeg op! Zeg op!"

"Moeraskimo!" riep Adam. "Ik dacht net..."

"Je moet niet zomaar DENKEN!" zei Moeraskimo boos. "En met een fjonk op je hersenpan moet je zeker niet aan MIJ denken, zolang er geen nieuws onder de zon is! Snap je?" Adam staarde verlegen naar zijn voeten en wist niet goed wat te doen.

"Nou? Waar wacht je nog op?" riep Moeraskimo. "Denk me onmiddellijk terug in het moeras. Ik wil hier geen uren blijven zitten!"

Opeens begreep Adam het. Hij kneep zijn ogen stijf dicht en dacht: Moeraskimo moet
terug in het moeras!

Hij opende zijn ogen. Moeraskimo was verdwenen.

Adam tilde de fjonk van zijn hoofd en hield hem stralend met twee handen voor zich uit. Nu begreep hij het. Een fjonk kon gedachten werkelijk laten gebeuren. Wensen
vervullen, als het ware. Dat was het geheim. Wat een ontdekking! Nu kon hij zichzelf regelrecht naar de magische deur denken.

"Moab! Moab!" riep de spookachtige moerasvogel in de verte. Uit de mist kwam weer
het dreigende geronk, maar Adam was zo uitgelaten dat hij niet luisterde. De fjonk in zijn armen viel met een zucht in slaap.

Een grote, zwarte schroeivlek.

De mist dreef in langgerekte, dunne slierten door de fjonkmoerassen. Adam zat op de
dikke boomwortel en keek naar de slapende fjonk in zijn armen. Hij porde het wezen wakker met zijn vinger. "Kom, kereltje. Er is werk voor je aan de winkel. Het is tijd om op te stappen." Slaperig opende de fjonk zijn ogen. Op dat moment voelde Adam de boomwortel waar hij op zat, bewegen. Opeens was er beroering in het moeras.

Moerasvogels krijsten. Kikkers brulden. Het zware geronk dat al die tijd had geklonken,
hield op. Naast het pad verscheen iets reusachtigs. Langzaam rees het uit het moeras omhoog. Het was drie meter hoog en twee meter breed. Adam zag een enorme, met paddestoelen begroeide hangneus, ogen groot als wagenwielen. De kronkelende boomwortels bleken haren te zijn, die aan alle kanten uit het hoofd en de wangen groeiden. Uit de oren kwamen groene struikjes. Op het hoofd zat modder en slijm. In de wortel-takken-struiken-baard krioelden kevers, padden en salamanders.

Het monster gaapte luid. Hij had een mond als een grot, waar vleermuizen uit fladderden. Adam zag dat er een kies ontbrak in het reuzengebit. Een kies zo groot als een koelkast.

Verstijfd van schrik verborg hij zich achter een boom. Hij besefte meteen wat daar voor
hem zat te gapen. Dat was de Molkroch, waarover Iblis de Oude gesproken had. Het wezen dat bomen at. En dit was alleen nog maar zijn hoofd. Het volgende moment kwam er een kolossale grijparm te voorschijn. Kalm plukte de Molkroch enkele bomen uit het moeras en propte ze in zijn keelgat. Ook de boom waarachter Adam zich  erstopt had.

De ogen van de Molkroch glinsterden toen hij Adam in de gaten kreeg. Met een tong als een tweepersoons beddenlaken likte hij zijn lippen af.

Volgens Iblis de Oude at de Molkroch alleen bomen, maar Adam wachtte niet af wat er
ging gebeuren. Hij zette de fjonk op zijn hoofd en wenste zich naar de magische deur van Iblis de Oude, de enige mogelijkheid om te vluchten uit deze moeraswereld. ZAP! Daar was de deur al, overwoekerd door moerasgras, ingeklemd tussen de twee wilgen.

Adam hoorde de Molkroch in de verte teleurgesteld brullen. "Pech gehad," grijnsde Adam. Hij wilde de magische deur al binnen gaan, maar bedacht zich. "Wacht even," mompelde hij. "Laat ik niet te haastig zijn. Die Iblis de Oude ziet er ook niet zo betrouwbaar uit. Wat zou hij op dit moment uitspoken?"

Omdat de fjonk nog steeds op zijn hoofd zat, werd deze wens onmiddellijk vervuld. De
magische deur leek van glas te worden. Adam keek regelrecht in de toren van de magiër. De ronde kamer was leeg en verlaten. Alleen onder het plafond zweefden geruisloos de vele kristallen bollen.

Plots maakte een kleine zwarte vleermuis zich los uit een nis in de muur. Hij daalde
neer in de magische cirkel op de vloer van de kamer. Opeens stond daar Iblis de Oude, de magiër met de rode ogen.

Adam hoorde de magiër op een rare manier grinniken, en zag hoe hij zijn arm uitstak.
Een van de kristallen bollen zweefde naar hem toe. De tovenaar plukte hem uit de lucht en liet hem ronddraaien op zijn hand.

"Hopelijk komt die sukkel vlug met mijn fjonk," hoorde Adam hem zeggen. "Dan
kan ik eindelijk de vloek opheffen, die mij in deze toren vasthoudt. Als beloning mag het ventje Adam in deze kristallen bol wonen. Een piepklein huisje van glas, helemaal voor hem alleen. Ja, ja!"

Adam was geschokt. "Hoor je dat?" fluisterde hij tegen de fjonk. "Als dank voor de moeite wil hij me betoveren en opsluiten in die glazen bol!"

Hij schrok op van een luid gebrul en het gekraak van brekende bomen. De Molkroch kwam eraan, op zoek naar zijn ontsnapte prooi. Adam stopte de fjonk in zijn zak en
liep de magische deur binnen, met een plannetje in zijn achterhoofd.

Meteen stond hij in de ronde kamer. Iblis de Oude schrok, toen Adam opeens voor zijn
neus stond. Maar hij herstelde zich vlug.

"Ach, dappere jongen! Ben je daar eindelijk? Heb je een fjonk voor mij bemachtigd?
Ja, toch zeker?" Met zijn rode ogen loerde hij onderzoekend naar Adam in de hoop een glimp van de fjonk op te vangen. "Nu? Waar wacht je nog op, jongen? Geef mij de fjonk. Zoals je ziet heb ik je beloning al hier in mijn handen." Hij toonde de kristallen bol. Deze keer liet Adam zich niet om de tuin leiden. Hij stak zijn hand in z'n binnenzak en voelde daar de rustige hartslag van de fjonk.

"Geef hier!" hijgde de magiër, die nu zijn geduld verloor. "Die fjonk is voor mij. Hoor je? Voor mij! Jij hebt er niks aan. Geef hem dus maar hier!" In zijn hebberigheid verloor de magiër zijn zelfbeheersing. Hij stortte zich met klauwende handen op de Jongen.

Dit had Adam verwacht. Vliegensvlug zette hij de fjonk op zijn hoofd. Hij dacht en
brulde tegelijkertijd: "Laat de Molkroch hem halen!" 

De magische deur vloog open, alsof een storm ertegenaan beukte. Een reusachtige
grijparm schoof naar binnen en de klauwhand pakte Iblis de Oude. De arm trok zich onmiddellijk terug en sleurde de krijsende magiër mee de moeraswereld in. Er klonk een triomfantelijk gebrul en de magische deur werd dichtgesmeten. Op hetzelfde moment viel de fjonk met een doffe klap op de vloer. Terwijl hij daar lag, loste hij op, tot er niets meer van hem over was, behalve de twee kikkerpoten.

Jammer, dacht Adam verdrietig. Deze laatste betovering heeft te veel van zijn krachten
gevraagd. Adam was aan het moeraswezentje gehecht geraakt, maar misschien was het beter zo. Een fjonk zou inderdaad een levensgevaarlijk wapen zijn als hij in verkeerde handen viel. Toen hoorde Adam een zacht gerinkel en getinkel. De kristallen bollen die onder het plafond zweefden, maakten rare, schokkerige bewegingen. Ze trilden, botsten tegen elkaar en vielen naar beneden.

Rondom Adam kletterden ze tegen de vloer. Hij moest steeds opzij springen om niet
geraakt te worden. Het was duidelijk dat de magische krachten die hen lieten zweven, uitgewerkt waren.

Adam wilde zo snel mogelijk weg uit deze toren van zwarte magie. Hij liep naar de deur die de uitgang naar de Holle Heuvels was. Achter hem klonk nog steeds het geluid
van brekend kristal.

Hopelijk zijn de weerwolven nu weg, dacht Adam. Voorzichtig duwde hij de deur een eindje open. Een zonnestraal kroop over zijn schoen en probeerde naar binnen te
glippen. Adam duwde de deur verder open. Geen gehuil van weerwolven. Geen
kolkend zwarte lucht vol regen meer. De lucht was blauw en de zon was stralend
en fel. De heuvels waren groen, vol gele bloemen. Vogels kwetterden vrolijke
liederen. Nu duwde Adam de deur helemaal open. Wat fijn was dat, na al die
nattigheid in de fjonkmoerassen! Hij stapte opgelucht naar buiten en gooide de
deur met een smak dicht.

Ogenblikkelijk stortte de toren als een kaartenhuis in, verbrokkelde en verkruimelde, tot er niets meer van over was. Alleen een grote zwarte schroeivlek bleef over.

Opgeruimd staat netjes, dacht Adam. Hij voelde zich blij en vrolijk. Het verbrokkelen van de toren betekende waarschijnlijk dat de zwarte magiër niet meer terug kon komen. Al wist je zoiets nooit zeker met zwarte magiërs. Met de toren was ook de magische deur naar de moeraswereld verdwenen.

Jammer, nu heb ik mijn beloning niet, dacht Adam Flux. Maar meteen werd hij weer vrolijk. Eigenlijk heb ik de mooiste beloning die er bestaat, dacht hij. Ik ben ontsnapt
aan weerwolven. Ik heb een zwarte magiër overwonnen en de Molkroch verslagen.
Op naar nieuwe avonturen. De enige plek waar ik nooit meer naartoe wil is Slaapgat.

Van <[Volksverhalen Almanak](https://www.beleven.org/verhaal/adam_flux_en_de_zwarte_magier)>
