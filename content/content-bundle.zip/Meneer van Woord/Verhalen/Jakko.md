---
Genre: Griezelverhaal
Leeftijd: 
- Bovenbouw
- Basisschool
- Voortgezet Onderwijs
---



# Jakko

Als je in de mist door de Vennen loopt, dan hoor je soms een vaag rinkelend geluid.

Het vage gerinkel achter een gordijn van mist. Veel mensen zullen bij het horen van dat gerinkel, zo vlug mogelijk de bewoonde wereld weer willen bereiken. Maar lang niet
iedereen is op de hoogte van dat afschuwelijke drama dat zich hier aan het
begin van de vorige eeuw heeft voltrokken.

Jacco's vader had na lange tijd weer werk gevonden. Doordat Jacco's moeder met haar man meeging naar het veen, had het gezin net genoeg om van rond te komen. Maar zij hadden een groot probleem: hun zoon Jacco.

Jacco was stom.
Jacco kon zelfs helemaal geen geluiden voortbrengen. En al gauw kreeg hij dan ook de bijnaam 'Stomme Jacco'. Dag in dag uit ging Jacco met zijn ouders naar het veen, waar hij 's morgens met een paar meter touw aan een boom vastgebonden werd. Zijn wereld was overdag net zo groot als de lengte van dat touw.

Maar Jacco werd ouder en af en toe wist hij te ontsnappen. Jacco's vader meende de oplossing voor dat probleem gevonden te hebben. Hij kocht een riempje waar hij een paar belletjes aan vastmaakte. Door dit 's morgens om de nek van Jacco te doen,
waren zij van een grote zorg bevrijd. Bij elke stap die de jongen deed, rinkelden de belletjes en was het tot op verre afstand te horen. Zijn vader had hem geleerd dat, wanneer hij de weg niet meer kon vinden, hij moest blijven staan en net zo lang met zijn hoofd schudden totdat ze hem gevonden hadden. Jaar na jaar voldeed deze manier best. Tot die mistige herfstdag in oktober.

Ondanks de mist die alsmaar dikker werd, lukte het Jacco zijn vader en moeder terug te vinden nadat hij die morgen het veen ingetrokken was. Onder het eten kreeg Jacco plotseling een goed idee: hij kon de overkant van het kanaal eens gaan verkennen. Hoewel zijn ouders het hem verboden hadden het smalle bruggetje te gebruiken, zag
Jacco nu zijn kans schoon doordat de mist hem natuurlijk ook een handje hielp.

Het verraderlijke veen aan deze kant van het kanaal golfde onder zijn voeten. Nog steeds rinkelden de belletjes aan Jacco zijn riempje op gehoorafstand van zijn ouders.
De mist werd alsmaar dikker en sloot als een dikke witte wolk om Jacco heen.
Door de gevallen herfstbladeren, zag de grond er zowat overal gelijk uit. De gedachte dat hij daardoor gemakkelijk in een moeraspoel kon lopen, bracht Jacco zo in paniek, dat hij van schrik geen stap meer durfde te verzetten. Hij bleef niet wetend van dit gevaar - stokstijf staan en dacht langzaam na over de mogelijkheden die hij had om weer veilig bij zijn ouders te komen. Eigenlijk had hij maar twee mogelijkheden: stil blijven staan en wachten tot de mist optrok of zo lang met het hoofd blijven schudden dat zijn vader en moeder aan het gerinkel wel horen moesten dat er wat aan de hand was. Jacco koos voor het laatste.

Hij maakte door het hevige schudden zo'n lawaai dat een paar meter verderop een zittende buizerd van schrik opvloog. De vogel scheerde rakelings over het hoofd van de jongen. Doordat de vogel pas op het allerlaatste moment te zien was, schrok Jacco hier zo -erg van dat hij zijn evenwicht verloor. Hij probeerde de val met zijn handen op te vangen, maar voor zich voelde hij geen enkele vastigheid. Met zijn handen scheurde hij door een tapijt van bladeren en... plons!

Even was het stil, nadat het laatste opspattende veen weer teruggevallen was. Jacco zag kans zijn hoofd nog weer boven het moeras te krijgen. Op dat moment hoorde hij zijn ouders vertwijfeld zijn naam roepen. Een paar keer. Een paar keer probeerde
Jacco ook tevergeefs vaste grond onder zijn voeten te krijgen, maar het
zuigende moeras gaf hem daar geen kans toe. Jacco besefte maar al te goed wat
het betekende als hij geen hulp kreeg.

Duidelijk hoorde hij nu zijn vader en moeder. Dieper en dieper trok de modderige massa het vechtende lichaam van Jacco omlaag. In een laatste wanhoopsdaad, rukte hij met alle geweld het riempje van zijn hals. Hij zwaaide er mee in het rond. Zijn neus kon hij nog net boven het moeras houden. Nog steeds hoorde hij zijn ouders zijn
naam roepen. Dan weer dichtbij, dan weer verder weg. De mist maakte het zoeken
zowat onmogelijk. Het moeras kende geen genade. Langzaam maar zeker verdween
Jacco zijn hoofd helemaal in het moeras. Alleen zijn hand stak er nog bovenuit.
En korte tijd daarna verdween al rinkelend Jacco zijn hand ook en daarmee zijn
riempje.

De moeraspoel had bezit genomen van Jacco. De dwarrelende herfstbladeren dekten de poel weer toe als voorheen. Een plotselinge windvlaag deed de mist uiteen vallen in flarden. Het betere zicht bracht Jacco zijn ouders dichtbij, maar de moeraspoel verraadde zich niet. Jacco mocht blijkbaar nooit meer gevonden worden.

Tientallen jaren later werd bij afgravingen van het veen het veenlijk gevonden van Jacco. Het veen had het lichaam in dezelfde houding laten staan als toen het er bezit van genomen had. Jacco kreeg alsnog zijn laatste rustplaats op het kerkhof in
Klazienaveen, maar het veen had zijn geest in zich opgenomen, evenals het riempje waar de belletjes aan bevestigd waren.

Dat vage gerinkel achter een gordijn van mist, dat zou nog in het oosterse bos te horen wezen als een wanhopig geluid uit vroegere tijden.

Van <[Tjakko](https://www.beleven.org/verhaal/tjakko)>
