# Op het kerkhof

Twee jonge meisjes, Maddy en Sue, waren beste vrienden die veel tijd samen doorbrachten. Maddy bracht de nacht door bij Sues huis toen ze besloten spookverhalen te vertellen. Maddy vertelde een verhaal dat ze van haar oudere broer had gehoord over hoe, als je een mes in een graf steekt, de persoon die daar begraven ligt zijn hand uitstrekt, je grijpt en je het graf in trekt.

Sue geloofde het verhaal niet. Maddy was het daarmee eens, maar zei dat ze bang was om het te proberen, ook al was het maar een verhaal.

Sue riep uit: 'Ik ben niet bang. ik zou het proberen. '

Maddy belde Sue's bluf en daagde haar uit om naar het kerkhof verderop te gaan en te bewijzen dat ze niet bang was.

Beide meisjes gingen beneden naar de keuken, waar ze een zaklamp en een mes vonden. Maddy besloot dat haar durf dom was en smeekte Sue om niet te gaan, maar Sue wilde bewijzen dat het verhaal bedrog was en dat ze niet bang was. Ze ging weg, de donkere nacht in.

Maddy zat aan de keukentafel te wachten op haar vriendin. Vijftien minuten verstreken, toen twintig. Eindelijk, na een half uur, rende Maddy naar de slaapkamer van haar ouders, maakte ze wakker en vertelde ze wat er was gebeurd. Ze huilde in de armen van haar moeder toen haar vader een zaklantaarn pakte en naar het kerkhof liep.

Toen hij terugkwam, was hij bleek en geschokt. Met plechtige stem vertelde hij Maddy en haar moeder wat hij had gevonden. Daar, op een graf, lag Sue, dood met volledig wit haar. De politie werd gebeld en na te hebben geluisterd naar Maddy's uitleg waarom Sue op het kerkhof was, bepaalde het onderzoek dat het om een ​​ongeluk ging. Toen Sue het mes in het graf stak, ging het door de zoom van haar nachthemd. Ze dacht dat ze was gegrepen door de persoon die daar begraven lag en stierf van schrik.


