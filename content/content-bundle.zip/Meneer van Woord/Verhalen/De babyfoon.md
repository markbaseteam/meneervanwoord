---
Genre: Griezelverhaal
Leeftijd: Voortgezet onderwijs    
dg-publish: true
---

# De babyfoon

Drie vrienden, Arjen, Jim en Richard, bedenken een goede grap. Ze gaan 'inbreken' op de babyfoons van jonge gezinnen in de buurt.

Ze kopen een babyfoon waar ze verschillende frequenties kunnen instellen, zodat ze de meeste kans hebben om een babyfoon te kunnen hacken,

Ze gaan op zoek naar jonge gezinnen: makkelijk te herkennen aan auto's met kinderzitjes, schreeuwlelijke felgekleurde gordijnen, of plastic speelgoed in de tuin.

Als ze een goed huis hebben gevonden, gaan ze op zoek naar de goede frequentie. Ze horen opeens het rustige slapen van een baby. Beet!

Arjen mag als eerste, naam begint toch met een A!

Hij kucht eens en zegt met een freaky stem: 'Here is daddy!'

Bijna meteen gaat het licht in een van de slaapkamers aan en iemand rent de kamer uit Ze komen bijna niet bij van het lachen.

Daarna mag Jim: 'Dit is je laatste nacht'

Een ijselijke gil volgt.

'Voltreffer'

Richard is de  laatste van de avond: 'Ik kan je bloed al bijna proeven'

De ouders praten druk door elkaar. Ruzieachtige stemmen klinken door het huis.

Vol trots gaan de drie vrienden terug naar huis.

Ze halen de grap nog een paar avonden uit, maar Arjen en Richard hebben er snel genoeg van.

'Het was leuk voor een paar keer, maar nu hou ik ermee op.'

Jim wil het nog een keer doen. De gezinnen in zijn buurt zijn wel zo'n beetje op of ze hebben al van de grap gehoord.

Jim gaat naar een dorp verderop, drie kwartier fietsen, maar dat heeft hij over voor een goede grap.

Hij vindt in het dorp een afgelegen huis, met in de tuin een paarse speelgoed krokodil.

Met zijn babyfoon zoekt hij de juiste frequentie. Binnen de kortste keren heeft hij die gevonden.

Hij pakt de babyfoon en spreekt in de babyfoon: 'Ik sta naast het bed van jullie kind. Pas maar op!'

En nu maar wachten op de reactie.

Maar…er komt geen reactie. Het blijft stil in het huis.

Jim wil al zijn fiets pakken en naar huis fietsen. Dan ziet hij dat het licht aangaat in de
kinderkamer met het schreeuwende motief.

Hij ziet een silhouet voor het raam verschijnen. Kijkt ie nou Jims kant op? Hij krijgt een
vreemd gevoel in zijn buik. Dan begint de babyfoon te kraken: 'Jim, ik kan je
zien. Pas maar op!'

Bij Jim slaat de paniek toe. Hoe kan dit? Hoe weet die vent zijn naam?

Hij springt op zijn fiets en rijdt zo snel mogelijk weg van het huis. De weg naar huis is lang. Op een kruising wil Jim oversteken als de babyfoon weer kraakt: 'Niet door rood
rijden, Jim'

Het wordt steeds creepyer. Jim kijkt om zich heen, is het die man in die rode Mercedes of die man in die vrachtwagen. Jim racet door het donker, bang voor de man die hem op zijn hielen zit. Tenminste als iemand hem op zijn hielen zit.

Bezweet komt hij aan bij huis. Hij doet de babyfoon uit en haalt de batterijen eruit. Rust.

Hij wast zich, poetst zijn tanden en gaat naar bed. Dan kraakt de babyfoon weer. Hoe kan dat, hij had m uitgezet

'Slaap lekker, Jim, droom maar van mij. Maak je een beeld van mij. En op een dag zul je zien of je gelijk krijgt. Wees op je hoed, Jim.'

De volgende dag hoort hij op het nieuws over de moord in het dorp. Twee jonge ouders en baby zijn vermoord.

Jim was op zijn hoede: weken, maanden. Maar na een jaar was er nog steeds niets gebeurd. En het begon te slijten. De babyfoon werd vergeten, weggegooid waarschijnlijk.

Jim trouwde en kreeg een kind. Toen pas begreep hij wat hij de ouders had aangedaan. Niets was zo dierbaar als je kind. Niets was zo kwetsbaar.

De babyfoon stond aan. Het rustige ademhalen van Jims baby klonk als muziek in zijn oren.

De babyfoon kraakte:
'Jim, jij was mij misschien vergeten, maar ik jou niet!'
