---
Genre: Griezelverhaal
Auteur: John Steinbeck
Originele_titel: The Affair at 7, Rue de M
Leeftijd: 
- Basisschool
- Voortgezet onderwijs
---

# Zwarte kauwgom

- Dennis heeft Halloween  gelopen. Dat heeft een tas vol snoep opgeleverd

- Vader waarschuwt dat hij  niets mag eten, voordat hij het snoep heeft gecontroleerd
  
  - Toffees met punaises
  
  - Langwerpige kauwgom met
     scheermessen
  
  - Bounty's met naalden

- Natuurlijk overtreedt Dennis  de regel van zijn vader. Hij vindt een heel speciale kauwgom: diepzwart  en glimmend

- Sigarenassmaak: Vader  bevrijdt hem

- Kauwgom komt weer tot leven  op de tafel

- Kruipt naar Dennis toe

- Vader vangt kauwgom in vel  papier en gooit het naar buiten

- Kauwgom komt onder deur door  op weg naar Dennis

- Vader pakt honkbalknuppel en  slaat kauwgom plat

- Kauwgom in zakdoek en in de  kliko

- Kauwgom gaat tekeer in kliko  en springt tegen deksel

- 's Avonds kruipt kauwgom in  de slaapkamer van Dennis

- Vader bevrijdt Dennis van  kauwgom: sigarenas, peuken, rottend fruit, schimmel

- Kauwgom in de open haard

- Kauwgom door sleutelgat in  slaapkamer Dennis

- In zijn mond: smaak:
   sigarenas, peuken, rottend fruit, schimmel en verbrand hout

- Kauwgom uit de mond, in de  auto, naar Parijs. Daar weggegooid in de berm

- Kauwgom onder band van een  vrachtwagen weer terug naar Dennis

- In de mond van Dennis:
   Sigarenas, peuken, rottend fruit, schimmel, verbrand hout en rubber

- Kauwgom uit de mond, onder  een pot

- Kijken naar worsteling en  rustig worden kauwgom

- Pot met deksel dichtlijmen,  ducttape, begraven, klaar
