---
Genre: Dierenverhaal
Leeftijd: Kinderen; Volwassenen
Auteur: Ted Hughes
Originele_titel: The trunk

---

# De Slurf

Botten:

-   God is moe van het maken van Olifant
-   Olifant afgeraffeld, geen vacht maar een dikke huid van olifantenklei
-   God rolt een bolletje klei van de klei onder zijn nagels en gooit het op de werkbank
-   Olifant vindt dat hij niet af is, God moet het compleet maken. Met een vacht, niet kaal
-   God vindt dat Olifant wel compleet is, Hup de savanne op
-   Olifant vraagt wat dat bolletje op de werkbank is. Dat is van mij, dat is mij
-   HIj overtuigt God ervan dat hij daar haren van maakt
-   God doet dat en ziet dat het goed is
-   Olifant blij, God onderuit in zijn leunstoel
-   Thee drinken, klei tussen zijn vingers, uit zijn handplooien en onder zijn nagels vandaan
-   Hij draait het rond, maakt het rechthoekig en dan vormt hij er een kleine slurf van. Hij heeft namelijk zin om een kleine olifant te maken
-   Gedachteloos blaast hij er zijn levensadem in
-   Een kleine slurf is geboren. En vindt ook dat hij niet compleet is
-   God zegt hem dat er geen klei meer is
-   Hij kan helpen, hij kan alvast op zoek gaan naar klei
-   Slurf graaft holletjes in de aarde, drukt die naar boven in hoopjes
-   God bekijkt de hoopjes, maar het is steeds geen olifantenklei
-   Dagen, weken, maanden, jaren, eeuwen, millenia gaan voorbij. Steeds geen olifantenklei
-   Maar Slurf geeft het niet op. Op een dag, ben ik een Olifant!

Soms is God moe. En helemaal toen hij olifant had gemaakt.

"Dit is de laatste keer dat ik zo iets groots maak"

Eigenlijk was hij zo moe, dat hij Olifant op het laatst een beetje afgeraffeld had. Normaal gesproken had hij hem een dikke, harige vacht gegeven. Maar hij bedacht zich dat Olifant dat helemaal niet nodig had. Als hij er gewoon klei op Olifant kletste en een goede dikke huid zou maken, dat zou dat ook goed zijn. Dus smeet hij handenvol speciale olifantenklei op het dier.

Eindelijk, zo rond 4 uur 's middags was het werk gedaan. En daar stond hij, Olifant, zijn kop van links naar rechts zwaaiend. Hij tilde eerst zijn ene grote voorpoot op en daarna de andere. Hij keek opzij uit zijn ondeugende kleine oogjes.

God was erg tevreden met zijn nieuwe creatie. Hij liep om Olifant en keek tevreden vanuit elke hoek. Ja, hij was erg goed gelukt. Hij schraapte de klei onder zijn nagels vandaan, draaide er bolletjes van en gooide die op de werkbank. Hij wilde net zijn werkschort af doen...toen Olifant schreeuwde:

"Maak me af! Ik ben niet compleet!"

God wilde antwoorden dat dat niet zijn werk was. Maar hij begreep wat Olifant bedoelde.

"Je bent af, je bent compleet. Hup, weg jij. Naar de savanne en lekker rondrennen. Pluk de dag!"

Olifant krulde zijn slurf boven zijn kop en trompetterde.

"Maak me compleet, maak je werk af!"

Hij draaide zijn staart in een boze knoop.

"Ik ben niet af, ik wil een vacht!"

God zei dat Olifant iets veel specialers had: Een huid van Olifantenleer.

"Ik wil geen dikke huid van leer, ik wil een vacht van bont! Je hebt me verkeerd gemaakt. Er is geen enkel ander kaal beest. Noem mij maar eens een ander kaal beest"

God wilde boos worden, maar dan ziet hij een traan uit het kleine bruine kraaloogje van Olifant komen, de traan maakt een donkere streep van zijn oog naar zijn mondhoek.

God haalde diep adem om zijn boosheid weg te drukken. Rustig antwoordde hij: "Olifant, ik ben bang dat er geen Olifantenklei meer over is."

Olifant krijste luid: "Oh, nee! Wat heb je daarnet weggegooid? Ik zag het wel, je had het in je hand. Je gooide het weg. Dat was van mij! Dat was mij!!!"

"Maar dat was niet genoeg"

"Dat was het wel" (Olifant schreeuwt)

"geef me een paar extra haren, Een paar is genoeg. Ik wil niet kaal zijn, niet nu al!"

God klopte Olifant even op zijn kop. Hij maakte heel voorzichtig borstelige haartjes van het kleine beetje overgebleven Olifantenklei. Hij plakte ze hier en daar op de kop van Olifant en hier en daar op de rug van Olifant. Maar de klei was al snel op.

"Hoe ziet het er uit? Hoe lijkt het?"

"Het lijkt. Het lijkt op het begin van een hele bos haar op je lijf. Het staat je goed, ik moet toegeven dat je toch gelijk had"

Olifant voelde zich gelukkig. Hij gooide zijn slurf omhoog en streek er mee langs de haren op zijn kop. Hij trompetterde en verdween huppelend naar de savanne.

God zakte vermoeid in zijn leunstoel op de veranda en keek tevreden uit over de grote vlakte. Zijn oude moedertje kwam een glas thee en een broodje in de vorm van een wulk brengen.

"Je handen zijn vies, je gaat zo toch wel in bad, hè?"

Maar daar God eigenlijk geen zin in. Hij ging onderuit in zijn stoel zitten en keek uit over zijn tuin en pulkte de laatste Olifantenklei tussen zijn vingers, schraapte het uit de lijnen van zijn hand en onder zijn nagel vandaan. Hij rolde er een bal van tussen zijn duim en zijn wijsvinger. Hij drukte de bal plat, hij drukte het in een vierkant. Hij dacht aan Olifant. Met deze klei had ik wat meer haar kunnen maken voor hem.

Hij dacht aan de machtige oren van Olifant en toen dacht hij aan de slurf van Olifant. Het was de eerste keer dat hij zoiets had gemaakt. Hij vond het een geweldige uitvinding. Hij had zin om nog zo een te maken. Misschien een kleinere.

Hij rolde de klei tussen zijn vingers, Gedachteloos vormde hij een slurf met vouwen en al. Daar lag ie op de palm van zijn hand, een piepkleine slurf.

Hij nam een slokje van zijn thee. Wat als ik een heel kleine olifant zou maken? Hij bracht de slurf naar zijn mond en blies er levensadem in.

Met een schok begreep hij wat hij had gedaan. "Idioot"

De slurf, kronkelde en kwam omhoog op zijn hand. "Idioot, nu heb je een levende slurf gemaakt zonder de bijbehorende olifant"

"Maak me af! Ik ben niet compleet"

Het slurfje kronkelde tussen de duim en de wijsvinger van God "Maak me af! Ik ben niet compleet. Waar is de rest van mij? Maak me af!"

Maar dat was het probleem, er was geen klei meer. Morgen moest hij naar zijn kleiputten gaan om nieuwe klei te halen. Maar Olifantenklei zou een probleem worden. Hij had behoorlijk veel Olifantenklei gebruikt, daarom was Olifant ook zo groot uitgevallen.

"Rustig aan, morgen haal ik nieuwe klei. Het zal helaas geen Olifantenklei zijn. Ik ben helemaal door de Olifantenklei heen."

"Wat? Geen Olifantenklei?"

"Ja, er is vast nog wel iets, ergens. Maar dat moet worden gevonden. Het is nogal zeldzaam en waardevol spul"

"Oh, nee. Oh nee-ee-ee" Slurf zat vol met Olifantengedachten, Olifantendromen, Olifantenwensen. Met iedere adem die hij ademde voelde hij zich meer en meer olifant. HIj moest er niet aan denken om een slurf te zijn zonder olifantenhoofd, zonder olifantenlijf en zonder olifantenpoten.

Toen kreeg God opeens een idee!

"Je kunt me helpen om het te vinden. Je kunt meteen beginnen"

"Ja, maar hoe dan?" snikt Slurf.

"Je graaft in de grond en duwt de klei naar boven. Ik kijk of het de goede klei is. Als het de goede klei is, maak ik je af, dan maak ik een kleine olifant van je. Begin ergens waar de aarde zacht is"

De slurf duwde zijn achterkant omhoog.

God pakte de slurf en gooide hem in een stuk zachte aarde. "Hup, daar ga je, begin maar"

De slurf begon te graven. En omdat hij van olifantenklei gemaakt was, was hij erg sterk. He groef in de grond, at het op en spuugde het weer boven de grond uit in klein kronkelige hoopjes.

"Is dit de goede klei?" En hij ging meteen weer naar beneden om meer.

Aan het eind van de dag liep God door zijn tuin. Overal lagen kleine hoopjes klei boven de grond. De slurf kwam met zijn goede kant boven de grond, trots rechtop: "En?"

"Sommige zijn te gebruiken om insecten van te maken, maar het is bij lange na geen Olifantenklei"

De slurf kromp moedeloos in elkaar.

"Ik zou morgen een rattenstaart van je kunnen maken, daar heb ik nog genoeg klei voor"

"Nee, nee, nee, nee! Ik zal het vinden, het gaat me lukken. Wacht maar af" En hij verdween weer in de grond, furieus gravend naar olifantenklei.

Dagen gingen voorbij, weken gingen voorbij, maanden, jaren, eeuwen en millenia. Slurf verdween in de grond, duwde hoopjes klei omhoog. Soms zag God ze liggen, altijd schudde hij zijn hoofd, omdat het nooit Olifantenklei was. Meestal had de regen de hoopjes al weggespoeld voordat God ze kon bekijken.

Maar de slurf bleef stug doorgaan, hij gaf de hoop niet op. "ooit, op een dag zal ik een hele olifant zijn. Ooit zal mijn familie de aarde doen trillen. Ooit"

Hij trompetterde zijn olifantentrompetter en de kleikruimels vielen van het plafond van zijn hol
