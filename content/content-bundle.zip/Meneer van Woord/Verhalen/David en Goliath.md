---
Auteur: Peter Dickinson
dg-publish: true
---
**David en Goliath**

*Verteld door Carl van Rabenhaupt bij het beleg van Grave in 1674, bij een bespreking van de strategie voor de verovering van de stad.*

Op de plaats…Rust

En rust…

En kauw op een noot als jullie willen, jongens. Oké, wat we vandaag gaan oefenen is het beschermen met het Schild tegen de Slinger. Het is een tactiek die je niet zo heel vaak zult gebruiken, maar je moet 'm wel kennen voor het geval je op een strafexpeditie gestuurd wordt naar een schapenland.

Hoor ik nu iemand zeggen: "wat is er zo erg aan schapen?" Helemaal niks jongen, totdat je een paar kudde buit wil maken en de beesten de andere kant op gaan dan jij wil. Maar het zijn niet de schapen waarvoor je moet oppassen, het zijn de herders. Kerels uit het ruige heuvelland, die jakhalzen en vossen hebben verdreven- beren zelfs- weggejaagd bij hun kudde, al hun hele leven lang. Een herder die een dier kwijtraakt, moet die eigenhandig terugbetalen aan zijn meester, tenzij je kunt bewijzen met een
karkas dat het dier door een roofdier is gedood. Snap je?

Nu, zie je het banier dat bij de tent van de Generaal is opgesteld? Hoeveel speerworpen heb je nodig om die banier te kunnen raken? Twee? Ben je gek? Dat is drie en een kwart worpen voor een doorgewinterde speerwerper. Niemand van jullie lukt het in vijf worpen, behalve misschien Linke Loetje hier. Nu, stel je voor dat je op een speerworpafstand van de banier staat, en je richt op de standaard, hoe vaak zul je die raken met vijf worpen? Geen enkele keer, niemand van jullie, zelfs jij niet, Linke Loetje. Maar een herder, die een beetje kan omgaan met zijn slinger, raakt die standaard 5 van de 5 keer. Standaard! En vanaf hier, oké twee van de vijf keer.

Dus het eerst wat je in je oren moet knopen. De reikwijdte van een slinger is 5 keer groter dan van een speer én dan ook nog vijf keer zo nauwkeurig. Wat het niet heeft is gewicht en daar heb je dan nog een kans tegen een slinger.
Tenminste.Als.Je.Weet.Hoe.Je.Je.Schild.Moet.Gebruiken!

Oké, nu zal ik jullie een verhaal vertellen dat niet in jullie militaire handboek staat, maar het is een uitmuntend voorbeeld van hoe je je *niet* moet verdedigen tegen een
slinger. Acht jaar terug was ik mee met een gevangenenescorte, terugmarcherend
vanuit Jeruzalem. Ik raakte in gesprek met een van die Hebreeërs–we hadden echt
ons uiterste best moetend doen om ze uit te hongeren. Maar goed, hij zei dat
hen uithongeren helemaal geen zin had gehad als ze een paar honderd mannen als
David op de stadsmuur hadden staan. David, zei ik. Wie is David? Dit was wat
hij mij vertelde.

Lang geleden waren de Hebreeërs niet meer dan een verzameling wilde stammen in de heuvels. Toe kregen ze mot met de buren, die Filistijnen, die bij de kust woonden. Die waren een tikkeltje meer beschaafd dan de Hebreeërs als ik het goed begrepen heb. Om een beetje beschaving in de stammen te brengen, besloten ze dat ze een koning nodig hadden. Dus kozen ze zelf een koning, een grote vent die Saul heette en ze vormden een soort van leger die de Filistijnen 2 of 3 keer onverwacht overvielen. Natuurlijk wilden de Filistijnen daar graag een einde aan maken, dus stuurden ze een echt leger de heuvels in om die wilden een lesje te leren en te laten zien wie de baas
was. Ze gingen niet plunderen en brandschatten, zoals gewoonlijk, nee ze maken
er een grote propagandastunt van. Ze hadden een professionele huurling
gestrikt, een reus van een vent, 2 meter 70 groot, zei die Hebreeër. Zijn
harnas woog net zoveel als ik en je zou er een hele kluif aan hebben om alleen
zijn speer maar op te tillen.

De Filistijnen trokken rond tot ze een plek hadden gevonden waar ze hun voorstelling konden opvoeren. Een ondiepe vallei waar de legers zich konden ophouden op de hellingen en met een mooie grote, open ruimte in het midden. zodat iedereen alles goed kon zien. Want een spektakel zou het worden. Ze stuurden de reus naar de open plek, naar de gevechtslinie, met zijn schilddrager tollend naast hem. De reus liep heen en weer op de open plek en hij schreeuwde naar de Hebreeërs dat ze een man moesten sturen om met hem te vechten. Maar zoals je wel zult begrijpen was er niemand, maar dan ook helemaal niemand die dat aandurfde. De dingen zagen er slecht uit voor Koning Saul. Want zie je, een leger van die wilde stammen, moet het eerst en vooral hebben van discipline en moraal. Ze kunnen echt álles, vooropgesteld dat ze winnen. Ik heb eens zo'n stam zien vechten met een doorgewinterd leger, en die stam veegde hun tegenstander, hup, van de kaart. Maar zo gauw ze verliezen heb je er ook totaal helemaal niks meer aan. Dus dat was de tactiek van die Filistijnen- de reus op en neer laten paraderen, ze uitdagend om met hem te vechten totdat ze met de
staart tussen de benen terug zouden gaan naar hun boerderijen. En waar was dan
het leger van Koning Saul?

Dus Saul was ten einde raad toen zijn eigen minstreel, een jochie dat David heette, het op wilde nemen tegen die reus. Dat is ook nog iets met herders, ze zitten de hel tijd in hun eentje tussen de schapen en ze worden heel handig met zelfgemaakte harpjes en fluiten. Worden ze gelukkig van. Deze David had dat ook gedaan, om zijn koning een beetje blij te houden, maar nu zei hij dat hij het ging opnemen tegen die reus. Koning Saul was ondertussen zo wanhopig dat ie alles wel wilde proberen. Hij wilde dat David de koninklijke wapenrusting zou dragen, zodat ie een beetje indruk kon maken op de troepen, maar dat was niet wat David in gedachten had. De volgende morgen pakte David zijn slinger en ging naar de rivier om een paar kiezelstenen uit de droge
rivierbedding te zoeken, een beetje zwaarder dan hij zou gebruiken voor een jakhals of zoiets. Het ging niet om de afstand, maar om het gewicht, weet je wel? Ik denk dat hij wel een paar oefenslingers heeft gedaan, ja, dat denk ik wel.

Nu, stel je voor, jij bent die reus en je paradeert op en neer langs die gevechtslinie, je roept en schreeuwt naar die wilden om iemand naar hem toe te sturen om met hem te vechten. De laatste drie dagen kwam d'r geen een en het wordt een beetje saai en eentonig. En, dan opeens, komt dit kleine ventje op je af, zonder een wapen bij zich, je ziet in ieder geval niks, geen spoor van een harnas. Rechterschouder bloot. Vergissing nummer 1. Je herkent niet de slingeraar. Ontblootte rechterschouder, da's gewoon een
weggevertje. Je kunt je niet voorstellen dat dit serieus is, dus je begint te schreeuwen, gewoon om 'm te laten schrikken. Hij schreeuwt terug en hij komt op je af, dus je komt in beweging om hem te ontmoeten. Vergissing nummer 2. Je maakt een schietschijf van jezelf. Tegen slingeraars is de regel: Blijf In Het Gelid. Beweeg naar voren, ja als je het bevel daarvoor krijgt, verklein de afstand totdat je je speer kunt gebruiken. Maar Blijf.In.Het.Gelid. Jij bent nog steeds de reus, weet je wel, en misschien ben je niet zo dom om te weten dat dat ventje gaat proberen om iets tegen je te doen, gooien of zo. Dus je pakt het schild van je schilddrager, die daar heel erg blij mee is. Vergissing
nummer 3. Verkeerde schild. Zo groot als deur, had ik dat al gezegd? Kijk, dit schild hier, dat is de juiste soort- De Babylonische Standaard Versie-, precies het goede gereedschap tegen slingers, groot genoeg om je hoofd en nek te beschermen, licht genoeg om snel heen en weer te kunnen bewegen. Het punt is namelijk dat een slingeraar altijd op het hoofd mikt. Een slingersteen is nooit zwaar genoeg om door een harnas heen te gaan. Snap je? Dus het enige wat je moet doen is je hoofd beschermen.

Nu, vergissing 4 heeft te maken met vergissing 1, en wat was dat ook al weer? Herken je vijand, toch? Weten wat hij gaat doen. Maar jij bent die reus, blunderend loop je naar voren, met je harnas dat net zoveel weegt als een volwassen man, met je grote, onhandige schild aan je arm en die grote, onhandelbare speer in je hand. Let je wel op wat dat kleine ventje doet? Nee, dat doe je dus niet. Het enige wat je denkt is om zo dichtbij mogelijk te komen en hem tot moes te slaan. Je gaat een vetvlek van hem maken. Hij rent naar je toe, maar opeens stopt hij en gaat in een speciale houding staan…zo.
Kijk me aan mannen! Benen ver uit elkaar, zie je? Zijn romp gedraaid, zijn linkerschouder dodelijk gedraaid naar….jou. Zo weet je dat hij jou op het oog heeft en niet iemand anders van de manschappen. Zijn rechterarm gaat naar achteren, je ziet
de kleine beweging in zijn pols waardoor zijn slinger gaat draaien. Je zult de
slinger niet zien, het draait te snel rond. Nu draait hij zijn rechterarm
omhoog. Zo…

En nu het schild omhoog. Klang!

Achterwaartse hoek omhoog, duw het schot naar boven weg, niet naar beneden naar je voeten of naar de zijkant naar het gezicht van je buurman. En dan, zogauw je het heerlijke geluid KLANG hoort, meteen het schild weer naar beneden, zodat je ziet wat de kleine klootzak nu gaat doen. Net zo simpel als garnalen pellen als je d'r een beetje handig in bent. Maar deed onze reus dat ook? Godsamme, nee. Hij banjerde naar voren, zijn schild naar beneden, en maar opgeblazen roepen en schreeuwen en uitdagen. En Davids eerste steen raakte hem precies in het midden van zijn grote, dikke voorhoofd. Maar helaas voor de kerel, niet dik genoeg! Daar viel hij om als de toren van de Sint Elisabeth, David trok het zwaard van de reus uit zijn hand en hakte zijn kop af.

Let wel, het was niet alleen dat die reus dood was. Kijk wat er gebeurde met de hele propagandamachine. De Filistijnen zien hun reus in vol vechtornaat aan stukken gesneden door mini Hebreeërtje zonder een wapen bij zich. En de Hebreeërs zien het ook. Voordat de Filistijnen ook maar over de schrik heen zijn, komen de wilde stammen in een golf van geweld op hen af. Geen tijd om in het gelid te gaan staan, geen tijd om een verdedigingslinie op te zetten, omdat de wilden al tussen hen in waren gekomen. En dat werd me een strafexpeditie, met ontelbare doden en ander leed.

Oké. Spuug die noot uit. Aan-Dacht. Schildoefening,
Anti-Slinger. Op mijn teken!

Eén, twee….
