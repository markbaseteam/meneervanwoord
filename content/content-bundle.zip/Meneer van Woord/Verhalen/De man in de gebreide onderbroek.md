---
Genre: Winterverhaal
Leeftijd: Volwassenen
---

# De man in de gebreide onderbroek

Expositie

​Er was eens een man die de hele dag voor de open haard zat. Dan warmde hij zijn handen aan de voorkant, aan de achterkant, en weer aan de voorkant en dan weer aan de achterkant. Soms stond hij op en draaide zich om. En warmde zijn achterkant. Daarna draaide hij zich haastig om en warmde zijn handen aan de voorkant. En dan weer aan de achterkant. Soms verdween er een vinger in zijn neus, dan had hij een gedachte. Maar met zo'n warm vuur bleef zo'n gedachte nooit lang op het topje van zijn vinger zitten. En hij schoot het propje met de gedachte in het vuur. En hij warmde zijn handen opnieuw aan de voor- en aan de achterkant. Zo ging het week in en week uit. En zijn vrouw, geloof het of niet, pikte het allemaal.

Motorisch Moment

Tot op die ene dag. Ze deed de deur van de voorraadkast open: LEEG! Ze liep naar de gang, deed de deur van de kelderkast open: ook LEEG! Ze ging de kamer in en deed daar een voorraadkast open: LEEG! En toen, toen knapte er iets bij deze vrouw. Ze liep
naar de man in de stoel, trok hem eruit en zei: 'Nu ga je de deur uit en je komt er niet in voordat je vlees, vis en gevogelte hebt gebracht. Ze deed de deur open, gaf hem een schop onder zijn kont en sloeg de deur met een klap dicht.

Conflictontwikkeling

Winter! En dan heb ik het niet over die winters van nu, nee, dit is meer een winter van 1963, Reinier Paping met ijspegels aan zijn neus. Snerpend koude wind, afgevroren 
tenen, bevroren hoornvlies. Zulke winters. En daar stond de man, bibberend van de kou buiten. Ach luisteraars, ik vergeet een dingetje. Hij had één gelukje, hij had namelijk zo'n witte, zelfgebreide lange onderbroek aan. Zijn moeder had die onderbroek nog voor hem gebreid. Ze had tegen hem op haar sterfbed gezegd:
'Jongen, beloof me dat je die onderbroek zult dragen tot het einde van je dagen.' GGGGHHH, dood.

En omdat hij erg van zijn moeder hield had hij het beloofd. Alleen was zijn moeder nu al 16 jaar dood en al die jaren was die onderbroek nog geen dag uit geweest. Alleen voor het hoogst noodzakelijke een stukje. Uhhh, maar dat is een heel ander verhaal. Daar stond de man, bibberend van de kou in de sneeuw. Hij moest nadenken, een goede gedachte had hij nodig. Maar door de kou kreeg hij zijn vinger niet in zijn
neus.

Hij ging zitten op een boomstammetje om na te denken. Maar de boomstam was glad en hij gleed eraf. En hij voelde iets onder zijn kont bewegen. 'Ik blijf zitten waar ik zit',
dacht-ie. En hij bleef net zolang zitten tot hij met zijn volle gewicht (en dat was wat) dat wat onder zijn kont zat tot stilstand had gebracht. Hij stond op, veegde de sneeuw van zijn kont, keek achter de boomstam en verdraaid: Een haas! Het arme beest had achter de boomstam zijn leger gemaakt en was geplet! 'Mooi', het wild was binnen!  

Wek, wek, wek, hoog in de lucht zag de man drie eenden. Een sneeuwbal, nee, een geweer, een geweer had hij nodig. Hij haastte zich naar meneer pastoor, omdat hij wist dat meneer pastoor de enige was in het dorp met een geweer.  'Zo, lang geleden dat ik jou in de kerk heb gezien, nietwaar?' 

'Ja, meneer pastoor, ja, meneer pastoor. U weet het, de vrouw, meneer, en druk, druk, druk. Maar zou ik het  geweer even mogen lenen? 

'Het geweer?'

'Ja, meneer pastoor'

'Spreken wij dan af, dat wij jou zondag in de kerk zien, hm?'

'Meneer pastoor, ik zal er zijn.'

Meneer pastoor, als een goed herder, neemt de man mee naar binnen, schenkt een jenever in en legt hem uit hoe het geweer werkt. 

'Kijk, je neemt het geweer en daarin gaat een propje, dan wat kruit, dan een kogel, dan weer  een propje. Dan met deze ijzeren pin de boel goed aanstampen. Pin eruit,
mikken, haan achterover en schieten.'

'Bedankt meneer pastoor.'

'Tot zondag.'

En daar liep onze man door de sneeuw. Wek, wek, wek, hoog in de lucht drie eenden. Hij zet onmiddelijk zijn geweer neer: propje erin, kruit erin kogeltje erop, propje
erop, ijzeren pin, mikken, haan achterover: KLABAM. 

Climax

De oplettende luisteraar heeft inmiddels door dat er wat mis is gegaan. De man is vergeten om de ijzeren pin eruit te halen. Pieeee, daar schiet de ijzeren pin de lucht in
op weg naar drie eenden. De achterste eend ziet de ijzeren pin aankomen, versnelt nog een beetje, maar euuhhh, gespiest. De tweede eend ziet het gebeuren, gaat nog iets sneller dan de eerste, maar ook hij wordt gespiest. De derde eend, helaas, ondergaat hetzelfde lot: gespiest. En dan luisteraar, doet de zwaartekracht zijn werk. Piiiieeeee daar staat de ijzeren pin midden in een vers bevroren meer met drie licht geplette eenden. Voorzichtig loopt de man over het krakende ijs naar de ijzeren pin toe. Hij trekt aan de ijzeren pin, maar die zit vast. Hij beukt met zijn geweer, net zolang tot het ijs kraakt, kraak, kraak, kraak en hij met twee handen de ijzeren pin uit het ijs kan
trekken. 

Heheheheh, aan zijn riem hangt een verse haas, aan de pin drie eenden, dan één plak ijs en dan onder het ijs, u raadt het al: vis! Hihihi, de buit is binnen! En onze man
begint weer naar de kant te lopen. Maar zoals gezegd, het was een versbevroren
meer en door het gebeuk met het geweer begon het ijs te scheuren. Te scheuren,
te scheuren, te scheuren. De man liep steeds verder totdat hij bijna in spagaat
was, maar het was te laat. Vak voor de kant: plons! In het IJSKOUDE water. De stukken ijs deinden door de golfslag opzij, botsten tegen de oever, kwamen terug, precies op het moment dat de man met zijn kop boven water kwam en de scherpe rand van het ijs, tsjoep: kop eraf. De stukken ijs botsten weer tegen elkaar, dreven opzij en daar kwam een hand uit het water, pakte het hoofd van het ijs en verdomd. Door het hoofd weer op zijn nek te plaatsen en tegen de rand van het ijs te houden, vroor zijn hoofd weer vast aan zijn lijf. Met moeite kwam hij op de kant. Liep naar het huis van meneer pastoor.

'Tot zondag'

'Ja, meneer pastoor, tot zondag.'

Afloop

Hij liep naar huis, en zijn vrouw: Hoh (verbazing): vlees, vis en gevogelte en ze nam het aan en ze rende meteen naar de keuken en hij meteen naar het haardvuur. Hohoho, en hij warmde zijn handen aan de voorkant. En aan de achterkant. En weer aan de
voorkant. En de achterkant. En toen stak hij één vinger in zijn neus, hoger en
hoger en hoger en plok! Kop d'r af.

Maar beste luisteraars, wat wij ook vinden van deze man. Hij was een man van zijn woord. Hij droeg, zoals hij zijn moeder had beloofd elke dag de lange, witte, gebreide
onderbroek tot het eind van zijn dagen. Hij bracht zijn vrouw vlees, vis en gevogelte. En, oh ja, hij was die zondag: in de kerk. Een man van het woord.
