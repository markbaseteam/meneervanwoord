---
Genre: Griezelverhaal
Originele_titel: The Golden Arm
Leeftijd:
- Basisschool

---

# De Gouden Arm

- Een man zoekt overal naar een  mooie vrouw. Op een dag vindt hij haar. Ze trouwen.
- De vrouw krijgt een ernstig  ongeluk. Haar arm moet worden geamputeerd
- De vrouw vraagt haar man om  een nieuwe arm. Omdat ik zoveel van je houdt, krijg jij van mij een gouden  arm
- De vrouw leeft gelukkig met  haar man en haar gouden arm.
- 'Als ik eerder sterf dan jij,  beloof me dan, dat je me begraaft met gouden arm en al'
- De vrouw sterft eerder dan de  man. Hij houdt zijn belofte en begraaft haar met haar gouden arm
- Maar als hij armer en armer  wordt, denkt hij aan al het goud dat hij heeft besteed aan de arm van zijn  vrouw
- Hij besluit de arm van zijn  vrouw weer op te graven
- Hij trekt zijn zwartste  kleren aan en gaat naar het kerkhof
- Hij graaft de kist op, opent  de kist en haalt de gouden arm eruit
- Als hij terugloopt, hoort hij  voetstappen achter zich. Hij hoort een stem: Wie heeft mijn gouden arm?
- Hij komt thuis, gooit de  schep onder zijn huis en hoort een stem: Wie heeft mijn gouden arm?
- Hij gaat het huis in, doet  alle deuren op slot: Wie heeft mijn gouden arm?
- Met de gouden arm onder zijn  arm rent hij naar boven, naar zijn slaapkamer: Wie heeft mijn gouden arm?
- Hij springt in bede, stopt de  arm onder het kussen: Wie heeft mijn gouden arm?
- De stem komt steeds  dichterbij. Hij kruipt diep onder de dekens. Maar de stem komt overal: Wie  heeft mijn gouden arm
- Hij kijkt met een oog boven  de lakens uit. Een hand komt door het raam, zonder het te breken
- Wie heeft m…JIJ HEBT MIJN  GOUDEN ARM!
