In Hattem, ik was een jaar of 14. The River van Bruce Springsteen was net uitgekomen. Hattem, in die tijd wereldberoemd door 't Heem. Veronica's Countdown kwam daar wel eens vandaan en zelfs U2 heeft daar opgetreden. Ik mocht daar niet naar toe, het concert was op Tweede Pinksterdag. Een no go dag in gereformeerde kringen. Maar goed, ik was 14 en had een vriendinnetje in Het Veld. Niks geen veld, maar grote vrijstaande huizen aan de Veldweg in het bos. Daar woonde Martin van Duinen, die op zijn verjaardag aandelen van Koninklijke Olie kreeg en die mij U2 leerde luisteren. Sietske Dane die mij leerde tafeltennissen. Maar Helma leerde mij op een hardhandige manier het verschil tussen links en rechts.

Tien uur, dan moest ik binnen zijn van mijn ouders. Tien uur, geen seconde later. Ik was op een doordeweekse avond bij haar. We luisterden naar Bruce, schuifelden op Drive all night, het langste nummer van het album. Bruce had bijna de schoenen voor zijn lief gekocht toen de klok 10 uur sloeg. In paniek een vluchtige kus en als een gek op de fiets. Ik kwam bij de ingang van het bos. Ik had twee keuzes: om het bos heen. Dat was veilig, maar lang. Of dwars door het bos, dat was gevaarlijker, maar kort. De keuze was snel gemaakt. Door het bos.

Voor de ingang van het bos stond een hek. Dat hek was dicht, daar moest je omheen. Je moest er aan de rechterkant langs. Hijgend kwam ik bij de ingang en in flits zag ik dat het hek open was. Ging het hek naar links of naar rechts open? Ik gokte en verkeerd.

Met een knal kwam ik in de beek terecht. Au!

Nu kwam ik nog later thuis. Dus dan maar met de fiets aan de hand door het bos. Ik draaide met het voorwiel zodat de koplamp naar het hek scheen, zodat ik het pad goed kon zien.

Ik liep het pad op. Zette het op een drafje. En daar stond opeens een groot harig, blauwig wezen met een groene hoed op zijn kop. Meer zag ik niet. Ik stond stil, het licht was uit, mijn ogen nog niet aan het donker gewend.

Het wezen pakte mijn stuur vast:

**Wurre mi e frotje son?** 
Pardon?

**Wurre mi e frotje son?** 
Sorry ik versta uw vraag heel slecht

**Wurre mi e frotje son?**
Ik begrijp nog steeds niet wat u zegt

**Wu-re mi e fro-tje son?**
Het was voor de vierde keer dat hij hetzelfde zei. Hij tufde daar nu zelfs een beetje bij

**Wur-re mi e fro-tje SON?**
Ik staarde naar zijn lippen en de woorden uit zijn mond Toen haalde ik mijn schouders op omdat ik er nog steeds niets van verstond

Hij begon nu te wijzen en te roepen 
**BUN NU ORE FUNGE KOEPEN! 
WUR-RE MI E FROT-JE S-O-N!**

Ik dacht dit gaat niet goed

ik moet hier weg dus zeg: Zal ik een woordenboek gaan halen Dat kan helpen met vertalen?

Nou, toen werd hij pas echt boos.

Hij greep me bij mijn nek tilde me een meter van de grond en hield me voor zijn kop die bijna op ontploffen stond

**WUR-RE MI EEEE FROOOTJEEEE SSSSOOOOON!**

Er piepten woorden uit de diepte van mijn dichtgeknepen keel

*Helf. Helf. Kurre mi nu oksi peel. Lumme lof, Helf. Mu niet wotte pat je fegt. Ajebief lumme lof. I pan nie porren tat je klegt*.

Ik dacht nu ga ik dood Hij liet me bijna stikken

Tot hij plots begon te lachen en te knikken

Omdat mijn keel per ongeluk het goede antwoord had gepiept.

Hij keek me vrolijk aan en vroeg;

**Possi munne piele klennen?**

Ik heb eerst netjes ja geknikt En ben toen zo hard ik kon gaan rennen met mijn fiets over het pad langs het hek het bos uit. Als een gek door de Elisalaan naar huis.

Met knikkende knieën het huis in. In de spiegel zie ik een hoofd vol met zwarte vegen. Op de tafel ligt een briefje: Wij zijn bij de overburen. Was het gezellig