---
Genre: Kerstverhaal
Auteur: Nicholas Allan
Leeftijd: Basisschool
---

# Geen Stille Nacht

Herbergier hoopt op een rustige nacht na alle hectiek van de dag.

De hele herberg zit vol met mensen die naar de stad moesten voor de volkstelling

Herbergier: Slaapmuts, gestreepte pyjama, wollen pantoffels en een olielampje
Stopwoord: Sakkerju

Openingsbeeld

De herbergier was trots op zijn herberg. Belangrijke mensen kwamen bij hem logeren. Nauurlijk omdat zijn herberg schoon was, omdat er lekker eten werd geserveerd: lamsvlees met heerlijke groente, de beste wijn uit de wijngaarden uit de omgeving. Maar ook omdat zijn herberg een oase van rust was. En die rust hadden zijn gasten wel nodig. Veel gasten hadden lang mnoeten reizen, omdat de keizer besloten had dat iedereen zich moest laten registreren in het dorp of de stad waar hij geboren was. Sommige mensen hadden dagen gelopen om hier te komen. Zijn heilige taak was het om de mensen stilte te gunnen.

De herbergier zelf was ook erg gesteld op zijn nachtrust. En zeker na vandaag, wat een drukte was het geweest. De hele dag had hij gerend en gevlogen om het zijn gasten naar de zin te maken. En nu, nu was het tijd voor zijn rust, nu was het tijd voor zijn stilte. Nu was het tijd voor hem om naar bed te gaann. Het enige bed dat nog niet beslapen was.

Hij ging de trap op, zijn slaapkamer in, deed zijn pyjama aan, zette het olielampje op zijn nachtkastje, stapte in bed, blies de lamp uit, trok de deken op tot aan zijn neus en viel in slaap.

Vijf minuten later werd er op de deur geklopt.

"Sakkerju", zei de herbergier. Hij stapte uit bed, stak zijn lamp aan, ging heel zachtjes de trap af om zijn gasten niet te wekken. Hij deed de deur open:

Voor de deur stond een man en een ezel en op die ezel zat een vrouw met een dikke buik. Hoogzwanger.

"Ja?"

"Heeft u nog een kamer voor ons?"

'Ik zit vol' zei de herbergier.

'Maar we zijn moe, we hebben dag en nacht gereisd.'

'Om de hoek is een stal. Hier zijn twee dekens en even tekenen graag.'

Dat deden ze, Jozef en Maria.

Hij ging de trap op, zijn slaapkamer in, zette het olielampje op zijn nachtkastje, stapte in bed, blies de lamp uit, trok de deken op tot aan zijn neus en viel in slaap.

Even later werd er weer op de deur geklopt.

"Sakkerju", zei de herbergier. Hij stapte uit bed, stak zijn lamp aan, ging heel zachtjes de trap af om zijn gasten niet te wekken. Hij deed de deur open:

'Het spijt me, kunt u ons een kleinere deken lenen? Deze is veel te groot.'

'Hier, een kleinere deken.', zei de herbergier.

Hij ging de trap op, zijn slaapkamer in, zette het olielampje op zijn nachtkastje, stapte in bed, blies de lamp uit, trok de deken op tot aan zijn neus en viel in slaap.

Maar toen maakte een verblindend licht hem wakker.

"Sakkerju!"

Hij stapte uit bed, ging heel zachtjes de trap af om zijn gasten niet te wekken. Hij deed de deur open en keek naar de lucht.

Daar stond de helderste ster die hij ooit had gezien.

'Dat kan er ook nog wel bij', zei de herbergier.

Hij ging de trap op, zijn slaapkamer in, stapte in bed, trok de deken op tot aan zijn neus en viel in slaap.

Even later werd er alweer op de deur geklopt.

"SakkerJU!"

Hij stapte uit bed, ging heel zachtjes de trap af om zijn gasten niet te wekken. Hij deed de deur open:

'Wij zijn drie herders.'

'Nou en? Zijn jullie je schapen kwijt, of zo?'

'Wij zoeken Jozef en Maria.' zeiden de herders.

'OM DE HOEK'

Hij ging de trap op, zijn slaapkamer in, stapte in bed, trok de deken op tot aan zijn neus en viel in slaap.

Even later werd er voor de zoveelste keer op de deur geklopt.

"SAKKERJU!!"

Hij stapte uit bed, ging heel zachtjes de trap af om zijn gasten niet te wekken. Hij deed de deur open

'Wij zijn drie koningen. Wij zijn gekomen om…'

'OM DE HOEK!!'

Hij ging de trap op, zijn slaapkamer in, stapte in bed, trok de deken op tot aan zijn neus en viel in slaap.

Maar toen verstoorde hemels gezang zijn rust.

"SAKKERDESAKKERDESAKKERDEJU!!"

Een koor van engelen zong en zweefde rond de herberg van de herbergier.

"Er is een kindeke geboren op aard'"

'NOU IS HET MOOI GEWEEST'

Hij klom uit bed, stommelde de trap af, gooide de deur open,

"Koppen dicht, engelen!"

De engelen stopten met zingen. Toen hoorde hij een baby huilen. Ook dat nog, zijn die enngelen eindelijk stil, krijg je het gekrijs van een kind.

Hij rende de hoek om, stormde de stal binnen en wilde net iets gaan zeggen, toen…

'Sssh,' fluisterde iedereen, 'Je maakt de baby wakker'

'Baby?', vroeg de herbergier.

'Ja, vannacht is er een kind geboren.'

'O', zei de herbergier en keek boos in de kribbe.

Precies op dat moment voelde hij dat tot zijn stomme verbazing, zijn woede verdwijnen.

'Ooohh,' zei de herbergier. 'Wat een kanjer!'

"Dit moet iedereen weten, wat een schat van een baby. Kijk eens wat een lieverd, wat een doediedoediedoe."

Hij rende terug naar zijn herberg, stormde de trap op. Hij gooide de deuren van de kamers van de gasten open. 

"Kom snel, de mooiste baby ooit is geboren. De mooiste baby, in mijn stal. Kom dan toch, kom!"

De gasten bromden en waren kwaad om de herrie die de herbergier maakte, maar ze gingen toch mee, nieuwsgierig als ze waren door het enthousiasme van de herbergier.

Toen zij in de stal kwamen waren ze het erover eens: Dit is echt de mooiste baby. Ze vierden de hele nacht feest, samen met de herders, de engelen, de koningen en Jozef en Maria.

Niemand deed meer een oog dicht die nacht.
