---
Genre: Kerstverhaal
Leeftijd: Basisschool
---

# Stille Nacht Tovernacht

Het was koud, die nacht. Een ijzige wind joeg de sneeuw op en de mensen die nog buiten waren haastten zich. Thuis brandde het vuur in de haard. De tafel was gedekt, de kaarsen waren aangestoken. Het was kerstnacht.

Nog maar één enkele man liep door de verlichte straten. Zijn rug was gebogen en hij liep maar voort door de sneeuw en de kou, zonder zelf te weten waarheen hij ging. Niemand wachtte op hem. Riton had geen familie en geen thuis.

De mensen keken naar hem als hij voorbij ging. Hij lette er niet op. Zonder achterom te kijken, vervolgde hij zijn weg. Hij floot zachtjes voor zich heen en de sneeuwvlokken bleven in zijn baard hangen.

Toch was hij niet alleen in die ijzige nacht...
Een hondje liep achter hem aan. Waar kwam hij vandaan? Om zijn nek had hij een halsband met een ster.

Toen Riton het hondje zag, begonnen zijn ogen te stralen. "Ben je verdwaald? Dan kunnen we beter bij elkaar blijven." De hond keek hem aan.

Beschut onder de takken van een grote spar pakte Riton een stuk brood uit zijn rugzak en sneed het in tweeën.
 Hier!" zei hij met een glimlach. "Het is een mager maaltje voor een avond als deze, maar meer heb ik niet."

Omdat het Kerstmis was vertelde hij een verhaal dat hij als kind heel mooi had gevonden. Daarna floot hij nog wat. Ook de wind floot. Steeds luider en luider, steeds kouder en kouder. "Kom," zei Riton. Hij zette de kraag van zijn oude, versleten winterjas op. "Laten we schuilen in die hut."

Ze zaten daar een hele poos, lekker warm in het stro. Toen klonk er opeens een stem: "Schrik niet en luister. Ik ben geen hond. Ik ben een tovenaar."

"Jij? Een tovenaar?" zei de oude man verbaasd.

"Vanavond heb ik mezelf in een hond veranderd, omdat ik degene die goed voor me zou zijn wilde belonen," zei de tovenaar. "En jij bent de enige die goed voor me was. Om je te bedanken zal ik je liefste wens vervullen. Vertel me wat die wens is."

"Ik wil geen grote dingen en ik heb niets nodig," zei Riton. "Maar ik heb altijd al een hond gewild."

De tovenaar dacht lang na. Was dat Ritons liefste wens? Toen besloot hij dat hij graag de beste vriend van de oude man wilde zijn. En hij gaf voorgoed zijn toverkracht op.

Heel vroeg de volgende ochtend verliet de oude man de hut om verder te trekken. En zijn vriend, de hond, volgde hem.

Van <[Stille nacht, tovernacht](https://www.beleven.org/verhaal/stille_nacht_tovernacht)>
