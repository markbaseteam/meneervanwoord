---
Genre: Griezelverhaal
Leeftijd: Basisschool

---

# Help, Lucas wordt opgegeten

- Luc en Sarah spelen in het  grote bos (sarah op de fiets, Lucas op de step)
- Maar dan wordt Lucas  opgegeten door een Schrokker (Groot, bruin, harig, met scherpe tanden en een heel lange tong)
- Sara raakt niet in paniek,  Schrokkers slikken hun eten in een keer door. Als ze snel is kan ze Lucas  weer uit de Schrokker krijgen
- Ze pakt iets uit de  struiken: dan moet ik niet vergeten dit mee te nemen
- Ls ze de Schrokker bijna  heeft ingehaald, wordt de Schrokker met Lucas in zijn buik opgeslokt door  een Grijpgraag (grote zwarte vogel met een enorme snavel)
- Sarah rijdt achter de  Grijpgraag aan tot bijna bij zijn nest
- Maar dan wordt de Grijpgraag  opgeslokt door de vreselijke Vreetvis
- Sarah graat de Vreetvis  achterna en ze haalt hem bijna in
- Maar dan wordt de Vreetvis  opgeslokt door de Stekelige Slokop, die lijkt op een dinosaurus met stekels op zijn rug
- Sarah heeft de Stekelige  Slokop bijna ingehaald
- Maar dan wordt de Stekelige  Slokop opgeslokt door de Harige Haaktand (die is zo groot als een heuvel,  zo harig als een beer en een schaap bij elkaar en hij heeft hoektanden zo  lang als een autobus)
- Sarah gaat de Harige  Haaktand achterna tot aan zijn hol
- Gelukkig wordt de Harige  Haaktand niet opgegeten onderweg
- Sarah wacht tot hij in slaap  valt, dan loopt ze voorzichtig zijn bek in
- Ze kruipt naar binnen en  klautert in de muil van de Stekelige Slokop, dan in de bek van de  Vreetvis, dan in de snavel van de Grijpgraag en tot slot in de bek van de
   Schrokker
- Daar zit Lucas. Ben je daar?
  Ik wist wel dat je zou komen. Hoe komen we hier uit?  
  Sarah doet haar tas open en haalt er een….kikker uit
- Ze laat de kikker  rondspringen in de buik van de Schrokker
- De Schrokker begint te  kokhalzen, de Grijpgraag begint ook te kokhalzen én de Vreetvis en de  Stekleige Slokop en als laatste de Harige Haaktand
- Totdat..een heel grote boer  de Stekelige Slokop, de Vreetvis, de Grijpgraag, de Schrokker en Sarah en Lucas worden uitgespuugd
- Nu hebben de dieren weer  honger en ze kijken likkebaardend naar sarah.
- Lucas: LAAT MIJN ZUS MET  RUST. ANDERS EET IK JULLIE ALLEMAAL OP!
- Zo snel als ze kunnen rennen  de dieren weg
