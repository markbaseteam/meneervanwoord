---
Genre: Griezelverhaal

Leeftijd:

- Bovenbouw PO
  
- Onderbouw VO
---

---

# De legende van Sint Walrick

Walrick is nu een heilige, maar daar klopt eigenlijk niks van. 

Rond het jaar 800 was hij een roverhoofdman, een van de meest gevreesde mensen van Novimagus en omgeving [Walrick beschrijven]. 

Hij gaf leiding aan de Hoemannen, rovers uit Heumen. 

De heirbaan door de vennen richting Nijmegen was hun werkgebied. Elke keer  als er een groep handelaars voorbijkwam, werden ze overvallen door de Hoemannen. Op bevel van Walrick die de duurste handelaars uitzocht overvielen ze en maakten de duurste dingen buit: gouden bekers, bronzen kelken, schitterend glaswerk. En als ze geluk hadden ook een mooie jonge vrouw. Het liefst overvielen ze christelijke handelaren. Die konden zo mooi bidden tot hun god als Walrick en zijn bende hen aan een boom vastbonden. 

De dorst naar dure dingen, geld en mooie vrouwen was nauwelijks te stillen. Walrick had een dochter, en al het goud, geld en vrouwen konden hem gestolen worden, zijn dochter was zijn alles. 

Op een dag wordt ze ziek, ze krijgt koorts. In die tijd is dat een ernstige ziekte, veel mensen stierven eraan. De lol was van het plunderen af. De medicijnman in het dorp kon er niks aan doen, ondanks de giften, offers en afranselingen van Walrick. 

Een van zijn bendeleden vertelde hem over de heilige Willibrord. 'Baas, die kerel ken dooien weer levend maken. Mensen die aan de galg bungelden, gingen weer leven, baas. Hij kan doodziek koortslappen weer beter maken.' 

Walrick gaat meteen op weg naar Noviomagus om deze Willibrord op te zoeken. 

Hij buigt een beetje diep voor de heilige man (je bent heiden of je bent t niet) en vraagt of Willibrord hem kan helpen. 

'Willi ik help je, ik maak je schathemeltjerijk als je mijn dochter geneest.' Willibrord
 kijkt Walrick aan: 'Ik ben een heilige, ik ben al schathemeltjerijk, dus daar heb ik niks aan. Ik help je. Beloof me twee dingen: 

- Wordt christen, laat je dochter dopen 

- Ga  om 12 uur vannacht naar de grote eik in het bos bij de Vennen. Hang 
  daar een haarband van je dochter (met het zweet van haar koorts) in 

Walrick  slikte en slikt, wikte en woog zijn woorden. Christen worden, ammenooit  niet, ik ben een trotse heiden, dikken neus met die god van Willi. 

'Ik zie aan je ogen Walrick dat je mijn god niet zo ziet zitten. Helaas voor jou is hij de enige die kan helpen' 

Met zijn vingers gekruisd achter zijn rug 'bekeert' Walrick zich tot het christendom. Zijn dochter wordt gedoopt. 

's Nachts om 12 uur hangt hij een zweetband van zijn dochter in de eik in het bos. 

Dan  volgt het wachten. Zijn dochter wordt zieker en Walrick staat op het punt om met de punt van zwaard Willibrord de waarheid te zeggen. Hij zadelt zijn paard, steekt zijn zwaard in de schede en gaat nog even bij zijn dochter langs. 

Dan ziet hij dat het beter gaat, langzaam maar zeker wordt zijn dochter beter. 

Karel de Grote hield vakantie in zijn favoriete kasteel, het Valkhof in Nijmegen. Hij werd ziek, koorts. Niemand die hem kon helpen. Totdat iemand hem vertelde over Walrick en zijn dochter. Karel liet iemand naar de eik rijden en een lapje van zijn bezwete kleding in de boom hangen. En Karel genas. 

Hij was door het dolle heen. Die Walrick moest worden bedankt. Hij bouwde voor hem een abdij bij de koortsboom. Een  abdij voor Walrick, de nepheiden. Met een bovenverdieping, voor een kluis. Voor een kluizenaar dus. Een alleenzitter die de hele dag aan god dacht en dacht en dacht. Niks voor Walrick. Maar een kluis daar kun je 
ook geld in bewaren.  

Als er mensen kwamen om zieken te genezen, dan zei Walrick: 

'Da kan. Hang een zweetlap in de boom, begraaf geld onder de boom en god geneest de zieke' 

Zo  werd Walrick geliefd bij de christenen en rijk van de christenen. Want Walrick was eens een boef altijd een boef. Hij groef het geld op bij de boom en stopte het in de kluis van de abdij. Iedereen blij? Walrick wel, zijn dochter wel, de genezen christenen wel. 

Maar zijn Hoemannen niet. Er was bijna niets meer te overvallen. De christenen hadden hun geld allang begraven bij de koortsboom. 

Ze zinden op wraak op hun oude baas. Op een nacht staken ze de abdij in de fik. Met Walrick en zijn dochter en de hele kluis erbij. 

Walrick werd heilig verklaard. 

Mensen komen nog steeds naar de koortsboom om er een lapje in te hangen voor een ziek familielid. 

Maar  kom er niet als de zon onder is. Als de zon onder is en de duisternis alles grijs maakt, komen Walrick en zijn dochter nog wel eens tevoorschijn om zijn oude werk op te pakken en mensen te overvallen.  Ook de overleden Hoemannen laten nog graag van zich horen. Hoemannen zijn Boemannen. Kom je in hun buurt, stop je vingers in je oren voordat ze Boe roepen. 

Pas ook op voor de medicijnmannen die Walrick heeft gedood. Ze zijn nog steeds op zoek naar wraak: neem geen drankjes van ze aan. Je gaat er niet dood aan, alleen wordt alle energie uit je getrokken. Als je elkaars hand vasthoudt, kun je in ieder geval de energie met elkaar delen.
