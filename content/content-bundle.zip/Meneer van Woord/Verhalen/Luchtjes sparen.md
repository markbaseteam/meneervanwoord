# Luchtjes sparen

Roosmarijn heeft een nieuwe hobby: luchtjes sparen in potjes

Ze vraagt of papa een scheet wil laten.

Hij doet het in de bank

Maar het moet als hij rechtopstaat met zijn broek naar beneden, dan kan Roosmarijn de scheet opvangen

"Dat is één" Ze doet het deksel op de pot en gaat met een andere pot naar buiten

Het is warm.

Jasmijnstruik geeft sterke lucht.

Mama komt de tuin in.

"Heb je nog potjes, mama?"

Mama vindt het maar gek, toch geeft ze de potjes uit de potjesdoos

Roosmarijn draait ze open. Eén ruikt nog naar aardbeienjam. Die draait ze snel dicht en zet m op haar potjesplank

Ze vangt meer geuren:

zeelucht

poeplucht van een hondendrol

lucht van pappa;s koffie

verflucht van de buurman

gebakken spek

verbrand spek

Ze gaat door tot ze 99 potjes heeft.

Lotje komt binnen in de tuin.

Nog 1 en dan heb ik er 100

"Honderd lege potjes? Wat heb je daar nou aan?"

"Ze zijn niet leeg er zitten geuren in"

Lotje opent een paar potjes. Opeens een vies gezicht. Draait snel het potje weer dicht.

"Dat was papa's scheet"

"Modderlucht?
Heb ik al?

"De geur van jonge poesjes?"

Ja

"Zure melk?"

Ja

"Vuilnisbak?"

Ja

Bloemen?
De meeste

Rijpe appels?
Nee, maar wel zure en bananengeur

Kauwgum?
Drie soorten en drop en chocolade

"Toch moet ik er nog één hebben!"

Vraag het dan aan de juf. Die weet het wel

En onweer

Maar het onweert niet.

Juf kijkt naar de lucht. Dat komt nog wel.

Juf vraagt of ze hooi heeft.

Nee,

Die moet echt.

Ze gaan naar de schuur en vullen het potje.


Als ze buiten komen is het donker, dreigend

Roosmarijn ruikt een vreemde lucht een belangrijke lucht.

Nu hebben ze geen potje meer

Ze gaan naar huis en kijken welk potje ze kunnen missen

Ze draaien hem open.

Papa komt binnen

Jesses wat een stank wie heeft een scheet gelaten?
Jij, lacht Lotje
