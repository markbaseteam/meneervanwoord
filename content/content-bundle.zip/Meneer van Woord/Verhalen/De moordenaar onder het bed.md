---
Genre: Griezelverhaal
Leeftijd: 
- Basisschool
- Middelbare school
---


De ouders van een jong meisje gingen een nachtje uit.
Hoewel ze nog jong was, dacht ze dat ze te oud was voor een babysitter. Ze
smeekt om alleen thuis te mogen blijven, ook al komen haar ouders erg laat weg.
Ze belooft om naar bed te gaan op haar normale bedtijd en belt haar ouders op
haar mobiel net voordat ze gaat slapen om hen te vertellen dat het goed gaat en
haar niet wakker te maken als ze thuiskomen. Ze zal ze morgen zien.

Ze slaapt bijna als ze druipende geluiden hoort. Ze staat op om te kijken of het buiten regent, maar de ster en de maan schijnen helder. Ze keert terug naar bed, en als ze haar ogen sluit, hoort ze weer het druipende geluid. Haar hand hangt uit bed en ze troost als ze voelt dat een natte tong eraan likt. Weten dat hun hond onder haar bed ligt, biedt troost.
Het druipende geluid gaat door en uiteindelijk besluit ze dat ze moet weten wat
het is.

Het jonge meisje staat op en doet het licht aan. Het geluid gaat door en ze blijft zoeken naar de bron. (Op dit punt kan de verteller het verhaal uitrekken en verschillende plaatsen beschrijven waar ze kijkt, d.w.z. de gang, de aangrenzende badkamer - wastafel en douche, enz.) Ten slotte kijkt ze in haar kast. Daar hangt haar hond, druipend bloed, met een briefje waarop staat: 'Mensen likken ook.'
