---
dg-publish: true
---
1. Anansi wedt met de koning dat hij op Tijger kan rijden als op een paard
2. Anansi had weer iets bedacht. Hij vertelde de Koning dat hij op Tijger kon rijden alsof die een paard was. De Koning lachte hem uit: "Zo'n kleine spin als jij... Hoe zou jij een gevaarlijk beest als Tijger in bedwang kunnen houden? Laat me niet lachen." - "Ik zal het u laten zien," zei Meester Superspin Anansi. "Gaat u maar over een uur op uw balkon staan."

3. Anansi bedenkt een list, waarvoor hij een bedorven ei nodig heeft
Anansi ging naar huis en riep zijn vrouw, ma Akoeba. "Waar is dat bedorven ei dat je vanochtend voor me wilde bakken? Je hebt het toch niet weggegooid!" schreeuwde hij. "Je weet dat ik nooit iets weggooi. Kijk maar in de vuilnisbak," schreeuwde ma Akoeba terug. "Wat ben je nu weer van plan?"

4. Anansi stopt het ei in zijn mond en gaat naar het huis van Tijger en jammert dat hij heel erg ziek is
Anansi antwoordde haar niet, hij had haast. Hij viste het ei uit de vuilnisbak, stopte het in zijn mond en rende naar het huis van Tijger Tigri. Voor diens deur zakte hij in elkaar, luid jammerend: "O, wat ben ik ziek. O, wat moet ik doen. Ik ga dood!!!" Tijger Tigri stormde zijn huis uit: "Wie gaat er dood?" - "Ik!" gilde Anansi. "Wat is er met je?" - "Ik weet het niet, mijn wang is helemaal opgezwollen." Tijger Tigri deinsde terug: "Je stinkt uit je mond!Je moet naar een dokter!" - "Dat haal ik niet meer," kreunde Anansi, "laat mij hier maar liggen doodgaan." Tijger Tigri kon het niet langer aanzien: "Zal ik je naar de dokter brengen?"

5. Tijger gaat Anansi naar de dokter brengen. Hij mag op de rug van Tijger klimmen. Hij valt er af en breekt zijn been. Hij mag op een kussen op de rug van de Tijger
Zo, dacht Anansi, het begin is er. "Ik kan niet op mijn benen staan," huilde hij. "Kom," zei Tijger Tigri, "klim maar op mijn rug." Anansi probeerde het, maar toen hij eindelijk op Tijgers rug zat, liet hij zich aan de andere kant er weer vanaf glijden. "Au, nu heb ik ook nog een been gebroken." - "Zal ik een kussen halen?" stelde Tijger Tigri voor en hij snelde zijn huis in om met een kussen terug te komen. Anansi keek ernaar en schudde zijn hoofd: "Wat heb ik daaraan, als ik me nergens aan kan vasthouden?"

6. Om niet weer te vallen bedenkt Tijger dat hij een touw in zijn bek moet nemen en dat Anansi die vasthoudt
"We hebben een touw nodig," bedacht Tijger Tigri. "Ik neem het in mijn mond en jij houdt de uiteinden vast. Ik heb een sterk gebit, dus je kunt trekken zo hard als je wilt." Anansi klom weer op Tijgers rug en zat nu mooi in het 'zadel' met 'teugels' in de hand.

7. "Zullen we?" vroeg Tijger Tigri. "Vooruit maar," fluisterde Anansi. "Wai, wai, wai," huilde hij even later. "Wat heb ik een pijn. Ik denk niet dat ik de dokter haal." - "Ik kan wel sneller," zei Tijger Tigri. Anansi lachte in zichzelf en jammerde tegen Tijger Tigri: "Au, au, nu je zo galoppeert, krijg ik last van muskieten."

8. Anansi heeft last van muskieten omdat Tijger zo hard loopt. Tijger zegt: Pak dan een tak die kun je gebruiken als zweep
Tijger Tigri stopte bij een boom: "Pak dan een tak en sla ze daarmee weg." Nu had Anansi ook nog een zweep die hij liet knallen, terwijl hij als een vorst de stad binnenreed, langs het paleis van de Koning. Die kon zijn ogen niet geloven. "Anansi rijdt op Tijger!" riep hij uit. Iedereen kwam kijken, de Koningin en het gehele hof.
Daar rijdt Anansi voor het bordes van de Koning langs en roept dat hij de weddenschap heeft gewonnen
Anansi spuugde het ei uit zijn mond, trok aan de teugels en liet Tijger halt houden. "Een kleine spin als ik, hè," schreeuwde hij triomfantelijk. Tijger Tigri kreeg door dat er iets niet in de haak was. "Moeten we niet naar de dokter?" brulde hij. "Nee, hier is goed. De Koning gaat me een beloning geven omdat ik jou heb bereden, Tigri." Tijger Tigri schaamde zich dood dat hij zich zo had laten beetnemen.

9. Als beloning mag Anansi n het paleis van de koning wonen. Nu zijn zelfs de paleizen niet meer spinnenvrij.
"Als beloning mag je met je gehele gezin bij mij komen wonen, Anansi," bood de Koning aan. Ha, zelfs paleizen zijn sindsdien niet meer spinnenwebbenvrij!

Van <https://www.beleven.org/verhaal/anansi_berijdt_tijger> 
