---
Genre: Dierenverhaal
Originele_titel: How the polarbear became
Auteur: Ted Hughes
Leeftijd:
- Basisschool
- Voortgezet Onderwijs
- Volwassenen

---

# Hoe IJsbeer op de Noordpool terechtkwam

Samenvatting: IJsbeer wint alle schoonheidswedstrijden die er worden gehouden in de Oude Wereld. De andere dieren hebben er snel genoeg van en broeden op een plan. IJsbeer op haar beurt baalt van alle zand en stof die haar vacht vies maken. Fregatvogel neemt haar mee naar de Noordpool waar alles mooi wit is, het ijs haar schoonheid weerspiegelt. IJsbeer gelukkig, de andere dieren gelukkig, want eindelijk is er voor hun ook een kans om te winnen.

Thema: Als je verwaand doet, kan het zomaar zijn dat je helemaal alleen komt te staan

Wie Waar Wanneer

|                      | Gegevens            | Details                                                                                     |
| -------------------- | ------------------- | ------------------------------------------------------------------------------------------- |
| Hoofdpersoon         | IJsbeer             | Het witste dier ter wereld, is daar zelf ook van<br> overtuigd. Verwaand door alle aandacht |
| Tegenstander         | Fregatvogel         | Jaloers, wil ook de mooiste zijn                                                            |
| Helpers hoofdpersoon | Zeeleeuwen          | Groupies van de IJsbeer                                                                     |
| Helper tegenstander  | Walvis              |                                                                                             |
| Plaats               | Pangea/Noordpool    |                                                                                             |
| Tijd                 | Begin van de wereld |                                                                                             |

Episode 1: Het begin van de aarde, alle dieren wonen bij elkaar Ze bewonderen alle mooie dingen van de schepping. Raken ze op uitgekeken

Episode 2: Kijken naar elkaar, bewondering. Schoonheidswedstrijd organiseren. De eerste keer wint Muis de wedstrijd, maar al gauw is het IJsbeer. Behalve op regenachtige dagen, dan wint kikker of eend of goudvis. Die dagen komt IJsbeer niet naar buiten, bang als ze is voor moddervlekken op haar mooie vacht.

Episode 3: Ijsbeer wint iedere schoonheidswedstrijd, zij krijgt steeds meer fans. Het Nijlpaard wijst haar kinderen op de schoonheid van IJsbeer. Neem daar maar eens een voorbeeld aan, kijk dat schitterende gebit eens. De Mol ziet weinig, maar de witte vacht van IJsbeer doet pijn aan zijn ogen. Vooral de zeehonden en zeeleeuwen zijn enorme fans. Ze gaan voor het hol van Ijsbeer liggen wachten tot ze naar buiten komt. Met hun Selffishsticks maken ze foto’s van hun grote idool.

Episode 4: De roem en bekendheid begint IJsbeer steeds meer tegen te staan. Maar erger nog is de stof die haar fans die op haar vacht terechtkomt. Door al dat stof komt haar schoonheid niet tot haar recht. Was er maar een land waar geen stof was...

Episode 5: Fregatvogel is al een aantal keren tweede geworden bij
de schoonheidswedstrijd. Hij wil wel eens winnen. Hij hoort wat IJsbeer zegt over het stof. Hij heeft veel gereisd en kent een land zonder stof. Hij vertelt erover aan IJsbeer. Zij raakt geïnteresseerd, opgewonden en wil zo snel mogelijk vertrekken.

Episode 6: Walvis wordt gecharterd, de zeehonden en zeeleeuwen staan huilend op het strand waar IJsbeer zal vertrekken. Huilend proberen ze IJsbeer op andere gedachten te brengen. Maar die is niet te vermurwen. Dus vragen ze of ze meemogen naar het nieuwe land. Doordat ze blijven huilen geeft IJsbeer uiteindelijk toe.

Episode 7: Fregatvogel wijst Walvis de weg. Ze komen aan op de Pool. IJsbeer ziet haarzelf in een ijsschots, ze loopt verlekkerd door de sneeuw. Ze voelt zich de koningin te rijk. Fregatvogel: Heb ik teveel gezegd?

Episode 8: Elke dag liggen de Zeehondgroupies te wachten bij het ijshol van IJsbeer. Elke dag als ze buiten komt roepen de Zeehonden: Oh je bent weer witter dan gisteren. Je bent werkelijk de koningin van de Pool.

Episode 9: En Fregatvogel? Die vliegt terug en is net op tijd voor de Schoonheidswedstrijd. De eerst zonder IJsbeer. En wie wint?

Focalisatie: EF
