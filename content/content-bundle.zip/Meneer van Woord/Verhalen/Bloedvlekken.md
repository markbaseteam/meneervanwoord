---
Genre: Griezelverhaal
Leeftijd:
- Voortgezet Onderwijs
- Volwassenen
dg-publish: true
---

# Bloedvlekken

Na de gruwelijke moorden stond het huis jaren leeg, De kranten hadden vol gestaan met de meest verschrikkelijke details van de brute moorden.

Elke keer als er aspirantkopers kwamen kijken schrokken ze terug van de verhalen die werden verteld over wat er gebeurd was tussen de muren van het huis.

Op een dag koopt een jong stel het huis. De familie de Valk viel voor het uiterlijk van het huis, de ligging en natuurlijk de lage prijs. Door de enge verhalen was het huis
praktisch onverkoopbaar geworden. Dat drukte de prijs enorm.

Voordat de familie de Valk erin kon trekken, moesten werklui nog wel de bloedvlekken van de muren halen, en uit het bad, en uit het aanrecht in de keuken.

Op de bovenverdieping moest nieuwe vloerbedekking worden gelegd om de weerbarstige vlekken te verbergen. En het huis moest meer dan een week luchten, om de vieze geur uit de gangkast te krijgen.

Meneer en mevrouw de Valk besloten om hun kinderen niets te vertellen over de bloedige geschiedenis van hun nieuwe huis.

Het was nergens voor nodig om ze onnodig bang te maken.

De eerste dagen verliepen vlekkeloos. De kinderen mochten een feestje houden en iedereen uitnodigen die ze wilden. Meneer en mevrouw maakten kennis met alle mensen in de buurt en nodigden hen uit voor een kop koffie of een glas wijn.

Het was heerlijk.

OP een avond liep mevrouw de Valk rond met een denkrimpel in haar hoofd.

'Wist je dat mevrouw Kooistra's handen in de keuken zijn gevonden?

'Oh, zei haar man, 'werkelijk?'

'Ja, maar haar vingers lagen in de eetkamer'

'Gatver, wat afzichtelijk.'

'Het is niet erg dat hij een geweer heeft gebruikt' zegt mevrouw de Valk, 'maar moest hij er nou zo'n bende van maken? Overal stukken en onderdelen. Een gore troep'

'Het was niet allemaal zijn schuld' zei meneer de Valk, 'Als mevrouw Kooistra nou niet per se zichzelf door het hele huis had willen slepen.'

'Nou ja, ze had zich niet hoeven voortslepen, als hij haar benen er niet had afgehakt' gaf mevrouw terug

'Ja, daar heb je misschien wel gelijk in, liefste' zei haar man 'Moeten we de gezusters
Karamazov niet uitnodigen? '

'Die twee roddeltantes? Zie mevrouw 'Die komen alleen maar om te kijken of wij alle
vlekken weggekregen hebben'

'Hij had het niet van tevoren bedacht om zoveel mensen te vermoorden. Hij wist toch niet dat de zus van mevrouw Kooistra zou komen? Of dat de postbode net die dag op dat moment aanbelde. Tja, vanzelfsprekend dat hij dan ook dood moest'

'Het was in ieder geval een troep' zei mevrouw de Valk. 'Ik denk dat ik nog even in bad stap voor ik ga slapen.'

'In het bad waar haar benen werden afgehakt?'

'Ja, want het bad beneden ziet er nogal goor uit.'

'Oké, in dat geval, fris ik me daar wel even op en wacht ik tot jij klaar bent.' zei meneer de Valk

Meneer de Valk ging zich scheren. Hij keek in de spiegel naar zijn eigen gezicht. Hij voelde zich vreemd. Hij voelde zich niet zichzelf.

Hij kreeg een raar gevoel over zich, alsof iemand anders de controle over zijn lijf overnam.

Hij liep de trap af naar de kelder, opende een deur van een kast. En daar stond het in de hoek.

Hij had geen idee hoe hij het wist, maar hij wist het gewoon.

De bijl.

Mevrouw de Valk zat voor de spiegel van de slaapkamer haar haar te borstelen en op te steken toen meneer binnen kwam.

Hij had zijn handen achter zijn rug alsof hij iets verborg. Op zijn gezicht lag een vreemde blik.

'Hé liefste, waar denk je aan?'

'Ik denk dat ik dit keer niet zo'n grote bende maak.'
