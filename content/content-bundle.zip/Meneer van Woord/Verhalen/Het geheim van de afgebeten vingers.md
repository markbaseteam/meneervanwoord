---
Genre: Griezelverhaal
Auteur: Rindert Kromhout
Leeftijd: Basisschool
---

# Het geheim van de afgebeten vingers

Karakterinformatie

**Wie  is het hoofdkarakter?**

Anna
 Barberini, prinses, nu een geraamte met zeis en weegschaal in haar handen

- Hangt aan het plafond in  grot 5 (de grot van de prinses)
- Zorgzaam
- Voorzichtig
- Bescheiden

**Doel van het hoofdkarakter**

Grot  6 vullen met nieuwe botten van kinderen, zodat haar broertjes een eigen grot
 hebben en zij verlost is van de zeis en de weegschaal.

**Obstakels en problemen voor het hoofdkarakter**

Anna  kan moeilijk booten verzamelen door de zeis en de weegschaal in haar handen.

Ze  weet niet de precieze opdracht, die komt stukje bij beetje van de schedels in  de grot

Ze  kan alleen 's nachts botten verzamelen, overdag zijn er mensen op straat

**Hoe wordt het probleem van het hoofdkarakter opgelost?**

Ze  slaat de vingers van liegende kinderen af en brengt die naar de grot

**Wanneer, waar, wie, wat en hoe**

Wanneer:  Geen specifieke tijd genoemd

Waar:  Rome - de kerk Santa Maria della Concezione (grotten met botten) & kerk
 Santa Maria Cosmedin (bocca della Verita)

Wie:
 Prinses Anna Barberini, Prinsen Enza, Dino en Fabio Barberini, 4000 schedels,  moeder en liegend meisje, jongen die wordt beschuldigd van stelen en liegen

Wat:
 Anna wil af van de zeis en de weegschaal in haar handen, daarvoor moet zij de  laatste grot vullen met nieuwe botten van kinderen

Hoe:
 Anna staat achter de mond van de waarheid. Als een kind zijn hand in de mond  steekt en een leugen vertelt, worden zijn vingers afgehakt. Als het de  waarheid vertelt, gebeurt er niks.

**Verhaalbotten**

1. Anna Barberini hangt aan het plafond van de 5e grot. In haar rechterhand een zeis, in haar linkerhand een weegschaal. Gemaakt van beenderen. Ook Anna is gemaakt van beenderen. Alles in de grot is van beenderen. Vijf grotten vol botten, alleen de zesde grot is leeg.
2. Anna klaagt dat de zeis en de weegschaal zo zwaar zijn. De 4000 schedels schudden hun hoofd. Snap je het dan niet Anna, er is een manier om van je zeis en weegschaal af te komen. Wat ligt er in deze grot? Botten. Grotten vol botten. Wat ligt er in de andere grotten? Grotten vol botten. En wat ligt er in de zesde grot? Niets helemaal niets. Die grot moet vol, ook dat moet een grot met botten worden. Hoe dan, waarmee dan, waarom dan? Maar de schedels zwijgen.
3. Krakend stapt Anna van het plafond. Haarbroertjes zitten in een hoek van de grot en willen graag helpen. Botten zijn er genoeg in de stad en we willen graag weg uit deze koude en stinkende grot. Ik weet wel waar je botten kunt vinden zegt Enzo. Ze lopen door de stad waar al veel mensen zijn dood gegaan aan de Pest. Ze komen in steegje waar fel licht brandt: een eethuis. Ze kijken naar binnen en zien dat alle tafeltjes bezet zijn door mensen die lekker eten. Kip, karbonade, stukken vlees met….botten erin! Als het restaurant dicht gaat gaan ze naar de vuilnisbakken en zoeken de botten er uit. De broertjes , want Anna kan niets doen met die zeis en weegschaal.
4. De botten zijn nog lang niet genoeg. Maar daar weet Fabio wel wat op: ze gaan naar het park. In het park wonen zwerfhonden en zwerfkatten die vlees krijgen van oude vrouwtjes. Daar verzamelen ze botten en kluiven en nemen die mee naar de
   grot. Ze maken de dieren aan het schrikken. Ze leggen de botten in de zesde grot.
5. Nou leg de zeis uit je rechterhand maar neer. Leg de weegschaal uit je linkerhand maar neer, je taak is volbracht. Anna probeert het , maar het lukt niet . Vierduizend
   schedels schudden het hoofd: Het is verkeerd Anna, het is net goed Anna. Je hebt poten van koeien, ribben van varkens, vleugels van kippen. Maar dat is niet goed. Botten van beesten heb je gehaald. En je moet botten van…mensen hebben. Teenkootjes, ellepijpen, schaambenen en stuitjes, dat moet je zoeken. Dino weet waar je die kunt vinden. Niet nu, zegt Anna, het wordt al licht. Nu uitrusten.
6. De volgende nacht gaan ze naar het kerkhof. Het moet een oud graf zijn, zegt Anna. Nee een nieuw graf is veel makkelijker zeggen de broertjes. De grond is dan nog lekker los. Oude graven hebben schonere botten zegt Anna. Ze komen familieleden tegen: Opa Marco, Neef Carlo en tante Laura. Die graven ze op, gezellig alle familie bij elkaar in de grot. Zo graven ze steeds meer botten op
   voor de zesde grot.
7. Maar weer schudden vierduizend schedels hun hoofd. Het zijn weer de verkeerde botten, het zijn wel mensenbotten, maar oude botten die al een keer begraven zijn,
   Het moeten verse botten zijn én van kinderen.
8. Anna vraagt zich af waarom zíj de botten de botten moet zoeken, waarom is het háár opdracht? Anna's broertjes kunnen niet wachten tot ze weer op pad gaan. Ze bedenken allerlei manieren om kinderen te vangen en dood te maken. We grijpen ze, we gooien ze in de rivier, we duwen ze van de Sint Pieterkerk, we sluiten ze op in de kelder en we geven ze geen eten, we steken een school inbrand als alle kinderen er zijn, we laten een nieuwe ziekte los, dan gaan er weer heel veel mensen dood. We prikken ze levend vast in de grot en geven ze geen eten. Dan gaan ze vanzelf dood, hoeven wij niks te doen. Nacht na nacht zwerven ze door de stad, zonder verse botten te vinden. De broertjes worden steeds somberder. Ogen hol, koude wind door de ribben.
9. Anna neemt een besluit: we stoppen ermee! Heeft lang genoeg geduurd. Vierduizend schedels kreunen: Je geeft het op? Je mag het niet opgeven. Anna zegt dat ze het zeker weet. Je kan niet stoppen, je mag niet stoppen, je hebt het beloofd! Jij zou voor je broertjes zorgen heb je je moeder beloofd. Ik zorg toch voor mijn broertjes? Ze zitten toch in mijn grot. In jouw grot ja, maar niet in hun eigen grot: De Grot van de Prinsen. Daar zijn de botten voor: hun grot. Ga weer naar buiten en vervul je belofte
10. Nacht na nacht loopt ze door de stad, het wordt winter en kouder en kouder. Ze heeft al zoveel plekken gezocht, maar ze moet door ze heeft het beloofd aan haar moeder. Op een dag gaat het mis. Het is al bijna licht. Anna probeert nog naar de
    grot te gaan, maar er zijn al teveel mensen op straat. Ze zoekt een plek om zich te verstoppen. Ze ziet bij een kerk een grot masker staan met een gezicht met een baard en een gat dat een mond is.
11. Anna vlucht achter het masker en ze zal wachten tot het helemaal donker is en er geen mensen meer op straat zijn.
12. Dan hoort ze voetstappen. Een kleine hand met een ring gooit geld in de mond van de kerk. Drie munten. Dan hoort ze stemmen. Dit jongetje zegt dat jij geld van hem hebt afgepakt. Anna gluurt door de mond en ze ziet een moeder, en klein jongetje dat huilt en een meisje met aan haar hand een ring. De ring die ze net zag. De ring aan de hand die geld in de mond deed. Nee hoor mama, ik heb het geld niet gepikt. Hij liegt. Het jongetje huilt: Wel, ze heeft het van mij gepikt. Ik had het geld van mijn oma gekregen.  
    Hij liegt hoor mama, ik heb niets. Kijk maar naar mijn handen, helemaal niets.  
    De vrouw kijkt streng naar de jongen: Dus jij liegt. Mijn lieve Lauraatje heeft helemaal niets gepikt. Mag jij liegen van je moeder?  
    Het is wel waar! Zegt de jongen  
    Hou je mond snauwt de vrouw en ze geeft hem een klap in het gezicht. Maak dat je wegkomt!  
    De jongen gaat weg. Ook de vrouw gaat weg. Het meisje niet. Zij loopt weer terug naar de mond in de kerk.
13. Het meisje kijkt om zich heen en steekt haar hand in de mond. Anna ziet de hand en ze wordt kwaad. Die lieve Laura heeft het geld wel gepikt, ze heeft gelogen. Wat
    gemeen!  
    Ze kijkt naar de hand van het meisje en ze wordt zooo kwaad dat ze met haar hand op de hand van het meisje slaat. Alleen…aan haar hand zit…….de zeis vast. De zeis slaat op de vingers van het meisje en de vingers vallen bloedend op de grond. Het meisje gilt het uit: Mijn vingers, mijn vingers zijn er af. Die mond heeft mijn vingers eraf gebeten. Ik wou het niet mama, ik wou het geld niet pikken, het ging vanzelf.
14. Er komen steeds meer mensen op het gegil af. Er staat al een hele groep bij de mond. Heb je het al gehoord, die mond bijt vingers af. Vingers van meisjes, vingers
    van meisjes die liegen. Al 30 vingers. Ook van jongens. Ik denk het wel. Al 100 vingers. Al snel is er niemand die het nog niet heeft gehoord. Het verhaal van de mond die al meer dan 1000 vingers heeft afgebeten.
15. Drie vingers denkt Anna. Vingers met botjes van kinderen. Het is niet veel, maar het is een begin voor de grot. Dan komt er weer een hand in de mond. Een kleine hand, een hand van een kind. Zeg dat het niet waar is buldert een zware stem. Zeg
    dat je het poesje niet hebt doodgemaakt. Maar pas op, als je liegt gaan je vingers eraf. Ik heb het niet gedaan zegt een andere stem. Ik heb het niet gedaan. Hij liegt ziet Anna, want zijn hand trilt. Ze tilt haar hand met de zeis op en tsjak, twee vingers van zijn hand af. Al vijf vingers voor de grot. Als het avond is heeft ze al 18 vingers voor de grot. Anna ziet en hoort meteen of een kind liegt of niet. Als de hand van het kind kalm in de mond wordt gestoken weet Anna dat het kind niet liegt, maar als het wel trilt, dan heft ze de zeis en….tsjak….En er wordt veel gelogen. Een jongen heeft zijn juf opgesloten in de kast. Een jaloers meisje had een baby in de vuilnisbak gestopt. Een ander kind had zijn oma in de steek gelaten midden op een drukke weg. Zij hadden hun verdiende loon gekregen.
16. Haar broertjes vonden het prachtig. Anna voelde zich raar. Toch gaat ze door, ze heeft het beloofd. Iedere dag verstopt ze zich achter het masker en luistert ze naar de kinderen die hun handen er insteken. En ze tsjakt wel of ze tsjakt niet. Soms zijn het grote vingers, die legt ze op de weegschaal, Zijn ze te zwaar? Dan gooit ze ze weg, die zijn van volwassenen die kan ze niet gebruiken.
17. Maar ze moet doorgaan tot de zesde grot, de grot van de prinsen is gevuld. Of dat is gelukt? Dat kun je zelf bekijken in de stad Rome. Kom straks maar even langs voor het adres.
