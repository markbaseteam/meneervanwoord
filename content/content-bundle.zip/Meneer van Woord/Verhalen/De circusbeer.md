**De Circusbeer**

*Karakterinformatie*

*Wie is het hoofdkarakter?*

- Grigori, de hotelhouder uit de Karpaten in Roemenië.
- Niet getrouwd, wel een werkster
- houdt van een borrel, vooral pruimenjenever
- houdt ook van opscheppen.
- Gezet
- niet snel
- niet heel slim

*Doel van het hoofdkarakter*

Meer gasten in zijn hotel krijgen. Dat kan als gasten de mogelijkheid krijgen om een beer te kunnen schieten. Een plezierjager komt op bezoek in het hotel van Grigore. Ze raken aan de praat en aan de drank en het gesprek komt op de dieren die er te schieten zijn in de omgeving van het hotel. Wolven, herten, wilde zwijnen, loopt er allemaal rond. En beren vraagt de jager. Beren, je ziet door de beren het bos niet meer.

*Obstakels en problemen voor het hoofdkarakter*

Het is winter, in de winter zijn er geen beren. En er zijn in jaren geen beren meer gezien

*Hoe wordt het probleem van het hoofdkarakter opgelost?*

Grigore ‘leent’ een circusbeer van een dorpsgenoot. Dimitru heeft een afgeleefde circusbeer in zijn achtertuin. Geen probleem als ze de beer niet raken, maar ook geen probleem als ze hem wel raken, want de beer is al oud. Eén ding: zorg dat er geen fiets in de buurt is. Het is namelijk een circusbeer.

*Wanneer, waar, wie, wat en hoe*

Wanneer: Eind jaren 80

Waar: Klein dorpje in de Karpaten in Roemenië

Wie: Grigore, de hoteleigenaar, de jager, de jagervrienden, Dimitru, de werkster, de circusbeer

Wat: Grigore wil meer gasten in zijn hotel, hij verzint beren om jagers te lokken

Hoe: Dorpsgenoot Dimitru heeft een oude circusbeer. Alleen mag die niet in de buurt van een fiets komen. Dat gebeurt natuurlijk wel. De werkster fietst naar het hotel. De beer pakt de fiets af en fietst door het dorp. De jagers zijn teleurgesteld en vooral boos. Grigore schaamt zich, verstopt zich in de kelder en wil niet meer tevoorschijn komen.

Verhaalbotten

1. Grigore heeft een vervallen hotel. Hij maakt zich zorgen over de weinig gasten die hij krijgt
2. Een plezierjager komt op bezoek. Grigore raakt met hem aan de praat over jagen. Ze nemen een borrel, ze worden steeds dronkener en Grigore vertelt overmoedig over de vele beren die er in de omgeving zijn.
3. Jager belooft terug te komen met zijn jagervrienden.
4. Ze komen terug als het net stevig heeft gesneeuwd.
5. Ze vragen aan Grigore of er beren te schieten zijn. Grigore denkt erover om te zeggen dat zijn hotel vol zit, maar hij kan de inkomsten goed gebruiken.
6. Grigore gaat op zoek naar een beer. Hij vindt de beer bij Dimitru,
7. Het is een circusbeer die vooral niet in de buurt van een fiets moet komen, want dan valt het plan van Grigore in duigen.
8. De beer wordt om 10 uur ‘s ochtends losgelaten op de weg achter het hotel
9. Grigore zit achter de struiken om te kijken hoe de beer zal worden geschoten
10. Hij hoort geluid in de struiken en zijn werkster komt gillend tevoorschijn. Haar fiets is gestolen….
11. Op dat moment komen de jagers langsrennen en horen we een fietsbel.
12. De jagers laden hun geweer. En jagen Grigore de kelder in.
13. De jagers vertrekken woedend bij het hotel en Grigore sluit zijn hotel voorgoed.

Dag meneer, wees welkom in mijn hotel: salut domnule, bine ai venit la hotelul meu

Stomme toeristen: turisti prosti

In de winter zijn er geen beren: iarna nu sunt urși

Door de beren het bos niet meer zien: din cauza urșilor nu mai văd pădurea

Dumitru, je moet me helpen: Dumitru, trebuie să mă ajuți
