---
Genre: Dierenverhaal
Leeftijd: 
- Basisschool
- Voortgezet Onderwijs
- Volwassenen
---

Op een dag zond de maan een insect naar de aarde en gaf het een opdracht mee: 'Vertel aan de mensen: zoals ik sterf, en stervende leef, zo zal ook jij sterven en stervende leven.' Het insect leerde de boodschap uit het hoofd en vertrok. Onderweg kwam het de haas tegen.


'Waar ga jij naartoe, beste vriend?' vroeg de haas.
'Ik ga de mensen een boodschap brengen van de maan. Ik moet zeggen: zoals ik sterf, en stervende leef, zo zal ook jij sterven en stervende leven.'
'Ik zal het wel doen,' bood de haas aan. 'Jij bent zo'n trage loper.' 

En voor het insect kon tegenpruttelen was de haas al weggezoefd.


De haas kwam bij de mensen en sprak: 'Ik heb een boodschap van de maan voor jullie. Luister goed: zoals ik sterf en stervende ten onder ga, zo zal ook jij sterven en ophouden te bestaan!' Daarna ging de haas aan de maan vertellen hoe goed hij zich van zijn taak gekweten had.


De maan was razend: 'Hoe durfde je mijn woorden te verdraaien?' Ze greep een houten stok, en sloeg er de haas hard mee op de neus. Sinds die dag heeft hij een gespleten lip. De haas vocht hevig terug en krabde het gelaat van de maan open. De littekens kan je elke nacht zien. Maar de mensen geloven nog steeds wat de haas hun verteld heeft. Was de haas er niet geweest, dan waren we na onze dood gewoon blijven leven. Telkens weer, zoals de maan.


Hottentot, Zuid-Afrika
