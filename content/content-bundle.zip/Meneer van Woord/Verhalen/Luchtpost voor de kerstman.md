---
Genre: Kerstverhaal
Leeftijd: Basisschool
---

# Luchtpost voor de kerstman

Martijn en zijn moeder woonden in een dorpje hoog in de bergen. Ze waren arm. Martijn had geen vader. Martijns moeder was naaister, maar in zo'n klein dorp is er niet veel naaiwerk. Martijn ging elke dag na school naar het bos om hout te sprokkelen dat hij kon verkopen. Toch hadden ze maar net genoeg geld voor wat ze echt het allernodigst hadden.

Op een avond kwam de bakkersvrouw haar nieuwe rok halen. Ze legde drie geldstukken voor Martijns moeder op tafel en een boekje voor Martijn. "Het is maar een oude agenda. Maar er staan mooie plaatjes in."

"Dank u wel!" zei Martijn blij. Hij ging met het boekje bij het flakkerende lampje zitten en bekeek de plaatjes. Het plaatje bij de maand december vond hij het mooist. Elk jaar komt de kerstman met zijn rendierslee vanaf de noordpool naar ons toe. Hij brengt cadeautjes mee voor alle lieve kinderen, stond eronder. Voor alle lieve kinderen? Ben ik dan niet lief geweest? vroeg Martijn zich af. Ik heb nog nooit een cadeautje van de kerstman gekregen.

"Mama, wat voor cadeautjes brengt de kerstman?" vroeg hij.

"Ik geloof dat hij geeft wat de kinderen graag willen hebben," antwoordde zijn moeder. Ze wreef in haar ogen. "Ik zou best een nieuwe lamp willen hebben. Dan zou ik beter licht hebben om bij te naaien. Kom Martijn, we gaan slapen."

Maar Martijn sliep helemaal niet lekker. Hij moest de hele tijd aan de kerstman denken. Misschien had de kerstman hem nog nooit een cadeautje gebracht omdat hij niet wist wat Martijn wilde hebben. Dat kon toch? Maar hoe moest Martijn de kerstman laten weten wat hij graag wilde hebben? Ach, het had ook allemaal geen zin. Verdrietig trok Martijn de deken over zijn hoofd.

De volgende ochtend kwam Martijn Dirk, de voerman tegen. "Ik heb wat voor je meegebracht," fluisterde Dirk geheimzinnig. Hij hield iets achter zijn brede rug verstopt. "Wat dan? Een snoepje? Of een paardje van houtsnijwerk?" raadde Martijn. "Fout! Helemaal fout!" lachte Dirk. Op dat moment ging achter hem bol en rood de
maan op. "Een ballon!"

"Die heb ik op de kermis in Urma voor je gekocht," vertelde Dirk. "En er zit speciale lucht in, waardoor hij kan vliegen."

Voorzichtig pakte Martijn het touwtje vast. Hij was er stil van. Dirk streek Martijn door zijn haar. Toen klom hij weer op zijn slee.

Dolblij met zijn mooie ballon liep Martijn weg. Die middag sprokkelde hij geen hout. Hij zat op het hek om de schapenwei en keek naar zijn ballon. Hij kon zijn ogen er niet van afhouden. Zo rood als de jas van de kerstman en zo rond als zijn buik. En hij danste zo mooi in de wind! Als Martijn het touwtje los zou laten, zou hij tot in de hemel vliegen. Of naar de noordpool. Opeens begon Martijns hart sneller te kloppen. Misschien kon de ballon zijn wensen naar de kerstman brengen! Martijn sprong van het hek en liep naar huis. Daar scheurde hij voorzichtig een blaadje uit zijn schoolschrift. Hij schreef een lange brief:

Lieve kerstman,

Ik heet Martijn en ik ben acht jaar.

Ik heb een plaatje van u in een agenda gezien en ik heb een paar wensen. Wilt u alstublieft een lamp voor mijn moeder brengen? En ik zou graag warme laarzen willen hebben. Mijn schoenen zijn zo koud in de winter. En graag ook warme handschoenen. De mijne zijn zo dun geworden.

Als ik maar één ding mag vragen, brengt u dan de lamp alstublieft.

Ik hoop dat u mij kunt vinden.

Ik woon in Strenca op de berg.

Kom alstublieft!

Uw Martijn.

Martijn vouwde de brief op en bond hem aan het touwtje van de ballon. Toen klom hij de berg achter het dorp op, helemaal tot de top.

Lang staarde Martijn in de verte. Waar zou de noordpool zijn? Moest hij zijn prachtige ballon nu echt laten gaan? Maar het was de enige manier om zijn brief bij de kerstman te krijgen. Martijn keek nog een keer of de knoopjes allemaal goed vast zaten. Toen drukte hij een kus op de dikke wang van de ballon en liet hem los.

Maar de koude bergwind blies niet naar het noorden. Hij kwam juist uit het noorden, en hij blies Martijns ballon naar het zuiden. Over bossen, bergen en dalen tot aan de zee. Aan de rand van een grote stad had de ballon niet genoeg kracht meer om verder te vliegen. Hij zweefde langs een dak naar beneden en kwam in een tuin terecht.

Even later kwam de oude Thijs uit zijn huisje. Hij zag de leeggelopen ballon. "Wat is dat voor rommel," bromde hij. Thijs was vaak brommerig sinds zijn vrouw gestorven was. Dat kwam doordat hij zich zo eenzaam voelde. Toen zag Thijs Martijns brief. Hij vouwde hem open en las hem. "Hij wil wat van de kerstman hebben," snoof de oude man.
"Ha! Wat verbeeldt die verwende aap zich wel! Wensen heb ik ook!" Thijs verfrommelde de brief en gooide hem in de vuilnisbak.

Maar die nacht sliep Thijs niet goed. Hij moest steeds aan de kerstman denken. Hij had vroeger ook wensen gehad, kinderen, kleinkinderen - en toch was hij helemaal alleen. En die Martijn was misschien toch niet zo'n verwend kereltje. Laarzen, handschoenen en een lamp voor zijn moeder. Welk kind vroeg nou zulke dingen aan de kerstman?

Heel vroeg in de ochtend stond Thijs op. Hij haalde Martijns brief weer uit de vuilnisbak. Strenca. Waar lag dat eigenlijk?

Twee dagen later stond er een wonderlijke, oude man op het station van Urma. Hij had een rode jas aan en hij had een zak vol pakjes bij zich. Boven zijn hoofd danste een rode ballon. "Hoe kom ik in Strenca?" vroeg de wonderlijke oude man. "Daar kun je nu alleen met een paardenslee komen," antwoordde de stationschef. "Hé, Dirk, kom
eens hier. Deze heer wil naar Strenca."

Een paar uur later werd er bij Martijn op de deur geklopt. En toen kwam de kerstman binnen. Echt, heus waar - de kerstman!
Hij had met bont gevoerde laarzen en heerlijk warme wanten voor Martijn bij zich. En een lamp die veel licht gaf voor Martijns moeder. Fruit en snoepgoed.
En de prachtige kerstballon had hij ook teruggebracht!

De kerstman bleef de hele nacht bij Martijn. Hij hield zijn hand vast tot hij in slaap gevallen was. Daarna praatte hij heel lang met Martijns moeder.

Toen het de volgende ochtend licht werd, laadden ze een bundel kleren, de nieuwe lamp en de naaimand op Dirks slee. Toen gingen ze naar het station van Urma.

Nu wonen Martijn en zijn moeder bij Thijs. Elke dag speelt Martijn na school in de tuin. De oude Thijs kan weer lachen en Martijn en zijn moeder noemen hem 'opa'.

Elk jaar als het Kerstmis wordt, kopen Martijn, zijn moeder en Thijs een rode ballon. Dan schrijven ze de kerstman een bedankbrief en binden hem aan het touwtje. Daarna
laten ze de ballon vliegen - over dalen, bergen en bossen naar de noordpool.

Van <[Luchtpost voor de kerstman](https://www.beleven.org/verhaal/luchtpost_voor_de_kerstman)>
