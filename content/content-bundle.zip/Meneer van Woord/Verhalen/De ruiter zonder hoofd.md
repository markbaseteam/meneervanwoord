---
Genre: Griezelverhaal
Auteur: Washington Irving
Originele_Titel: Legend of Sleepy Hollow
Leeftijd:
- Basisschool
- Voortgezet Onderwijs
---

# De ruiter zonder hoofd

De ruiter zonder hoofd- Een griezelig en spannend Halloween verhaal uit de V.S.

In het holst van de nacht als de schaduwen het donkerst zijn, de sterren schitteren en
de wind de wolken in het gezicht van de maan blaast, rijdt de ruiter zonder hoofd over het Slaperige Slingerpad. Onzin! Ik hoor het je zeggen. Maar probeer eens in je eentje 's nachts over dat pad te rijden als het krassen van een kraai klinkt als de roep van een arme verdwaalde man. Als de glimwormen op knipperende ogen lijken en het ruisen van de takken klinkt als rammelende mensenbotten. Als je denkt het geluid van paardenhoeven te horen op het pad achter je.

Zo verging het Hendrik van Dalen die vroeger schoolmeester was in die streek. Een
gestudeerd man, een verstandig man - behalve als hij toevallig 's nachts over
het Slaperige Slingerpad reed. Dan zong hij altijd hard om zichzelf te bemoedigen. Hij had een mooie stem: er waren tijden dat de leden van het kerkkoor zondags in de kerk met open mond bleven zitten, terwijl ze hem in zijn eentje lieten doorzingen.

En dansen dat hij kon! Zodra hij op de dansvloer stapte dromden de bedienden samen voor de ramen en in deuropeningen, alleen maar om Hendrik van Dalen te zien springen en huppelen. Hendrik was niet van plan zijn hele leven schoolmeester te
blijven. Hij had zijn zinnen gezet op Katerina van Tassel, de dochter van de rijkste boer uit de omgeving.

Katerina zei geen ja en geen nee. Maar ze glimlachte zo lief tegen Hendrik dat Bram Boon groen werd van jaloezie. Bram Boon had besloten dat Katerina het ideale meisje
voor hem was op de dag dat hij haar zijn lievelingskikker voor haar verjaardag had gegeven en zij Bra m in de paardentrog had gegooid omdat hij de kikker in haar jurk had gestopt. Tijdens het feest op Halloween in de schuur van Van Hasselt danste Hendrik de sterren van de hemel. Met zijn liedjes wekte hij alle vogels die zaten te slapen op de dakspanten. En zodra bij het open haardvuur de spookverhalen aan bod kwamen had Hendrik er ook een paar te vertellen.

Toen stond Bram Boon op en vroeg: "Heb je ooit gehoord van de ruiter zonder hoofd op het Slaperige Slingerpad?" Hendrik knikte.

"Heb je hem ooit gezien?" vroeg Bram Boon. "Ik wel, afgelopen herfst toen ik naar huis reed. Ik was helemaal niet bang! Ik deed een wedstrijd met hem, wie het hardst kon rijden, en ik heb het gewonnen ook. Maar toen we bij de brug over de rivier kwamen, zag ik opeens een grote vlam, waarin hij verdween."

"Echt waar?" vroeg Hendrik.

"Ja!" riep Bram Boon. "Net zo waar als dat ik hier dit verhaal sta te vertellen!"

"Wat een moed!" zuchtte Katerina, terwijl ze Brom met glanzende ogen aankeek.

"Ha, ha!" zei Hendrik, die er geen woord van geloofde, tenminste niet tot hij zelf in zijn eentje langs het eenzame Slaperige Slingerpad naar huis reed.

De nacht leek donkerder dan anders. Hij hoorde de uil roepen en de krekels sjirpen. Hij
probeerde een liedje te zingen om de moed erin te houden, maar zijn stem klonk zo beverig dat hij alleen maar nog banger werd.

Het had een opluchting moeten zijn toen een andere ruiter naast hem kwam rijden, die
dezelfde weg naar huis nam. Maar op de een of andere manier luchtte het hem niet op. Er was iets met die ruiter. "Goedenavond," zei Hendrik.
Klonk zijn stem maar niet zo beverig. Geen antwoord.

"Bent u vanavond ook op het feest bij Van Hasselt geweest?" Nog steeds geen antwoord.

"Het is een mooie nacht. Heel zacht voor de tijd van het jaar!" Geen antwoord.

Toen drukte Hendrik zijn hielen in de buik van zijn paard om het dier tot grotere
snelheid aan te sporen.

De andere ruiter bleef naast hem rijden. Hendrik hield in om de ander voorop te laten
rijden. Maar dat deed de ander niet.

Naast elkaar reden ze door zonder een woord te zeggen. Toen kwam de maan vanachter een wolk tevoorschijn en kon Hendrik zijn gezelschap duidelijker zien. Hij was een grote man met brede schouders.

Maar zonder hoofd! Hendrik schreeuwde, gaf zijn paard de sporen en ging er in galop
vandoor. Maar de ander kwam met een woest "Jahoeoe!" achter hem aan.

En daar galoppeerden ze over het Slaperige Slingerpad, Hendrik van Dalen gevolgd door de ruiter zonder hoofd, naar de oude brug.

Wat had zijn rivaal Bram Boon ook weer verteld over de brug in die nacht dat hij de
ruiter zonder hoofd had uitgedaagd voor een wedstrijd? Toen ze bij de brug kwamen was het spook in een grote vlam verdwenen!

Hendrik moest dus bij de brug zien te komen. Achter hem reed de ruiter in galop.
Hendrik voelde diens adem in zijn nek en hoorde het gedreun van de spookhoeven
in zijn oren. Toen hij bij de brug kwam durfde hij om te kijken en hij zag dat de ruiter zijn afgehouwen hoofd uit zijn mantel haalde en het door de lucht naar hem toe gooide!

De volgende dag werd Hendriks paard gevonden, terwijl het kalm stond te grazen bij
de brug. En van Hendrik van Dalen was alleen maar zijn hoed over die vlakbij het paard in het gras lag. Ze vonden ook een Halloween-pompoen waarin ogen en mond uitgesneden waren. Maar wat die te maken had met de vreemde verdwijning van de schoolmeester heeft nooit iemand begrepen. Niet lang daarna trouwde Katerina met Bram Boon, zoals ze altijd van plan was geweest.

Sommige mensen zeggen dat Hendrik van Dalen die nacht de stad uitreed toen hij begreep dat Katerina hem niet wilde hebben, maar anderen weten wel beter. Zij zeggen dat de ruiter zonder hoofd hem te pakken kreeg. Ze zeggen dat als je in het
donker, in het holst van de nacht, over het Slaperige Slingerpad durft te rijden en luistert naar het geluid van trappelende hoeven, je misschien ook de stem van Hendrik van Dalen hoort die een liedje zingt om de moed erin te houden.

Van <[De ruiter zonder hoofd](https://www.beleven.org/verhaal/de_ruiter_zonder_hoofd)>
