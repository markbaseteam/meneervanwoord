Auteur:: Ted Hughes
# Karakterinformatie

**Wie is het hoofdkarakter?**
Kat, die het liefst de hele dag viool speelt
	• Lui
	• Speelt viool
	• Gelukkig

**Doel van het hoofdkarakter**
Lekker luieren overdag en 's nachts vioolspelen

**Obstakels en problemen voor het hoofdkarakter**
De andere dieren vinden dat Kat een baantje moet zoeken. Ze benoemen een comité (Gaai, Ekster en Kaketoe) dat steeds achter Kat aanvliegt en tegen hem zegt: 'zoek een baan. Zoek een baan'

**Hoe wordt het probleem van het hoofdkarakter opgelost?**
Kat is het zo zat, het vliegende comité achter hem aan. Hij gaat naar de rand van het bos en steekt het veld over naar de boerderij van Mens. Daar neemt hij een baantje als muizen- en rattenvanger. Overdag jaagt hij op ratten en muizen. 's Nachts speelt hij viool en danst met de poezen.

**Wanneer, waar, wie, wat en hoe**
Wanneer: Aan het begin van de wereld
Waar: In het bos en op de boerderij van Mens
Wie: Kat, Bever, Wezel het comite van Gaai, Ekster en Kaketoe, Mens
Wat: Kat wil een lui leventje en 's nachts vioolspelen
Hoe: Hij neemt een baantje bij Mens als ratten- en muizenvanger. Overdag vangt hij net genoeg zodat het niet opvalt. 's Nachts speelt hij viool, samen met andere katten. Later komen ook de poezen en dansen ze hele nachten.

**Verhaalbotten**
1. Alle dieren hebben wel iets te doen, Bever knaagt bomen om, Leeuw is al beroemd om zijn moed en zijn brullen. Maar kat…
2. Kat zat opgerold in zijn boom niks te doen. 's Nachts als iedereen sliep kwamen de ergste geluiden uit de holle boom waar kat woont. De vleermuizen staken hun vleugels in hun oren. Wat een nachtmerries heeft Kat. 
3. Maar Kat stemde zijn viool en componeerde nieuwe wijsjes de hele nacht.
4. De andere dieren hebben er genoeg van. Bever: Hij is een slecht voorbeeld voor mijn kinderen, straks denken die ook dat je de hele dag maar kunt lummelen. Wezel: Het wordt tijd dat Kat ook een baantje krijgt. Net als iedereen op de wereld
5. Er wordt een comité gevormd van Ekster, Gaai en Kaketoe. Die gaan Kat er steeds op wijzen dat hij een baan moet zoeken.
6. Waar Kat ook loopt in het bos, steeds komt het comité achter hem aan: 'Zoek een baan, Zoek een baan!'
7. Kat wordt er helemaal gek van, hij kan niet eens meer rustig vioolspelen
8. Hij gaat naar de rand van het bos, de andere dieren volgen hem nieuwsgierig. Hij steekt het veld over naar de boerderij van Mens
9. Kat belt aan en vraagt naar een baantje. Mens heeft een ratten- en muizenvanger nodig
10. In het begin gaat het niet zo goed, de ratten en muizen zitten meer achter Kat aan dan andersom. Maar het gaat steeds beter. Hij vangt steeds meer, maar niet teveel anders zou hij zijn baan kwijt zijn
11. 's Avonds ligt Kat lekker bij Mens en vaak op schoot bij Vrouw. Heerlijk
12. Andere boeren zien hoe goed het gaat met een kat als muizenvanger. Ze nemen ook een Kat.
13. En elke nacht spelen de katten van de boerderijen op hun viool. Als ook de poezen komen wordt het een geweldig dansfeest
